import numpy as np
import h5py
from scipy.stats import zscore
import torch
from torch.utils.data import Sampler, IterableDataset, DataLoader
import pandas as pd
from tqdm import tqdm
from utils import load_config
import logging
from datetime import datetime, timedelta
from random import shuffle
from numba import njit,jit
from joblib import Parallel, delayed

def process_code_indices(code, code_set):
    return np.where((code_set == code))

@njit
def get_alpha_and_label(alpha, label, vi, code_index, window):
    indices = vi[:, None] - np.arange(window)[::-1]
    indices_flat = indices.flatten()
    alpha_value = alpha[indices_flat, code_index, :].reshape(indices.shape[0], window, alpha.shape[2])
    alpha_value = alpha[indices, code_index, :]
    alpha_value = np.nan_to_num(alpha_value, nan=0)
    label_value = label[vi, code_index]
    return alpha_value, label_value

class DateSampler(Sampler):
    def __init__(self, dataset):
        self.dataset = dataset
        self.unique_codes = self.dataset.unique_codes
        indices_by_codes = Parallel(n_jobs=-1)(delayed(process_code_indices)(code, self.dataset.code_set) for code in self.unique_codes)
        self.indices_by_codes = dict(zip(self.unique_codes, indices_by_codes))
        self.indices_by_codes = {key: value for key, value in self.indices_by_codes.items() if value is not None and len(value) > 0}
        self.shuffle = True if self.dataset.flag == 'train' else False

    def __iter__(self):
        if self.shuffle:
            shuffle(self.unique_codes)
        for code in self.unique_codes:
            yield np.expand_dims(np.array(self.indices_by_codes[code]), axis=0)

    def __len__(self):
        return len(self.indices_by_codes)


class H5_Dataset_30min_backNd_time_6_3d:  ## one sample with self.window times
    def __init__(self, h5_path, window_size, train_start_date, train_end_date,
                 valid_start_date, valid_end_date, test_start_date, test_end_date,# date_list, 
                 label,lazy_load, flag, alpha_names="all") -> None:
        if train_start_date > train_end_date or valid_start_date > valid_end_date or test_start_date > test_end_date:
            raise ValueError('input date error')
        h5_file = h5py.File(h5_path, mode='r')
        self.stock_num = 200
        self.window = window_size
        self.time_points = 4
        self.lazy_load = lazy_load
        if self.lazy_load:
            self.alpha = h5_file['data']
        else:
            self.alpha = h5_file['data'][:]
        self.train_start_date = train_start_date
        self.train_end_date = train_end_date
        self.valid_start_date = valid_start_date
        self.valid_end_date = valid_end_date
        self.test_start_date = test_start_date
        self.test_end_date = test_end_date
        self.lazy_load = lazy_load
        # self.date_list = date_list
        self.dates = np.array(h5_file['dates'])
        self.times = np.array(h5_file['times'])
        self.flag = flag
        if isinstance(label, str):
            self.label = np.array(h5_file[label])
        elif isinstance(label, list):
            self.label = np.vstack([np.array(h5_file[x]) for x in label]) 
        else:
            self.label = np.array(pd.read_pickle('data/min_labels_h5/close2close_30min')['return_30'])
        
        self.universe = np.array(h5_file['valid_index'])
        self.n_times = int(self.alpha.shape[0])  ## dates * time_points
        self.alpha_names = alpha_names
        self.codes = np.tile(np.array(h5_file['codes']), self.n_times).reshape(self.n_times, self.stock_num)
        if type(alpha_names) != str:
            all_alpha_names = np.array(h5_file['alpha_name']).astype('U')
            self.alpha_index = np.isin(all_alpha_names, alpha_names)
        self.valid_index, self.stock_valid_index = self._get_valid_indices()  # 直接对应的采样对象是原始的data
        self.code_set = np.where(self.stock_valid_index, self.codes[self.valid_index], np.nan)
        self.unique_codes = np.sort(np.unique(self.code_set))[~np.isnan(np.sort(np.unique(self.code_set)))].astype(int)

    # @jit(nopython=False)
    def _get_valid_indices(self):
        all_indices = np.arange(0, int(self.n_times - self.window + 1))
        end_index = all_indices + (self.window - 1)
        end_index = end_index[all_indices % self.time_points != 0]
        universe_range = self.universe[end_index[:, None] - np.arange(self.window)[::-1]]
        label = self.label[end_index]
        valid_indices = (~np.isnan(label)) & (universe_range.sum(axis=1) == self.window)
        valid_start_dates = self.dates[end_index]
        train_start = np.where(valid_start_dates >= self.train_start_date)[0][0]
        train_end = np.where(valid_start_dates <= self.train_end_date)[0][-1]
        valid_start = np.where(valid_start_dates >= self.valid_start_date)[0][0]
        valid_end = np.where(valid_start_dates <= self.valid_end_date)[0][-1]
        test_start = np.where(valid_start_dates >= self.test_start_date)[0][0]
        test_end = np.where(valid_start_dates <= self.test_end_date)[0][-1]
        if self.flag == 'train':
            print("training samples total=", np.sum(valid_indices[train_start:train_end+1]))
            return end_index[train_start:train_end+1], valid_indices[train_start:train_end+1]
        elif self.flag == 'valid':
            print("valid samples total=", np.sum(valid_indices[valid_start:valid_end+1]))
            return end_index[valid_start:valid_end+1], valid_indices[valid_start:valid_end+1]
        elif self.flag == 'test':
            print("test samples total=", np.sum(valid_indices[test_start:test_end+1]))
            return end_index[test_start:test_end+1], valid_indices[test_start:test_end+1]
    
    def __getitem__(self, index):
        vi = self.valid_index[index[0]]
        code_index = index[1][0]
        if self.lazy_load:
            indices = vi[:, None] - np.arange(self.window)[::-1]
            indices_flat = indices.flatten()
            alpha = self.alpha[indices_flat, code_index, :].reshape(indices.shape[0], self.window, self.alpha.shape[2])
            # alpha = np.array([self.alpha[v - np.arange(self.window)[::-1], code_index, :] for v in vi]) #速度慢
            alpha = np.nan_to_num(alpha, nan=0)
            label = self.label[vi, code_index]
        else:
            indices = vi[:, None] - np.arange(self.window)[::-1]
            alpha = self.alpha[indices, code_index, :]
            alpha = np.nan_to_num(alpha, nan=0)
            label = self.label[vi, code_index]
            
            # alpha,label = get_alpha_and_label(self.alpha, self.label, vi, code_index, self.window)#这个方法无法跑通

        if type(self.alpha_names) != str:
            alpha = alpha[:, self.alpha_index]
            
        if self.flag in ['valid', 'test']:
            test_date = self.dates[vi,code_index]
            test_time = self.times[vi,code_index]
            datetime_able_instrument = self.codes[vi, code_index]
            return alpha.astype(np.float32), label.squeeze().astype(np.float32), list((test_date, test_time)), list(datetime_able_instrument)

        return alpha.astype(np.float32), label.squeeze().astype(np.float32)
        
    def __len__(self):
        return len(self.valid_index)

if __name__ == "__main__":
    data_config = load_config("configs/data_config_timeseries_3d.yaml")
    data_set = H5_Dataset_30min_backNd_time_6_3d(h5_path=data_config.h5_path,window_size=data_config.window_size,
        train_start_date=data_config.train_test_split.train_start_date,train_end_date=data_config.train_test_split.train_end_date,
        valid_start_date=data_config.train_test_split.valid_start_date,valid_end_date=data_config.train_test_split.valid_end_date,
        test_start_date=data_config.train_test_split.test_start_date,test_end_date=data_config.train_test_split.test_end_date,
        label=data_config.label,lazy_load=data_config.lazy_load,flag='valid',alpha_names=data_config.alpha_names
    )

    sampler = DateSampler(data_set)
    data_loader = DataLoader(
        data_set,
        batch_sampler=sampler,
        pin_memory=True,
        num_workers=0
    )
    for i, (batch_x, batch_y, test_datetime, test_able_instrument) in enumerate(data_loader):
        ##batch_x 三维: [同一天的所有股票， 可视窗口，因子矩阵]
        ##batch_y 一维: [同一股票的折叠股票]
        print(i)
        print(batch_x)
        print(batch_y)
