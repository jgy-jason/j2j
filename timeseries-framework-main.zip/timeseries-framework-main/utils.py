from typing import Any
import yaml
from models import *
import logging
import torch
import random
import numpy as np
import copy
from collections import deque


def set_seed(seed_value):
    """固定所有可能的随机种子以确保结果可重现"""
    random.seed(seed_value)  # Python内置随机库
    np.random.seed(seed_value)  # Numpy库
    torch.manual_seed(seed_value)  # PyTorch的CPU随机种子
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed_value)  # GPU随机种子
        torch.cuda.manual_seed_all(seed_value)  # 如果使用多个GPU
        # torch.backends.cudnn.deterministic = True  # 确保每次返回的卷积算法是确定的
        # torch.backends.cudnn.benchmark = False  # 如果网络输入数据维度或类型上变化不大，关闭以提高训练速度

class EarlyStopping:
    def __init__(self, patience=7, verbose=False, delta=0, avg_epochs=5, save_path="ckpt_new/debug.bin"):
        self.patience = patience
        self.verbose = verbose
        self.counter = 0
        self.early_stop = False
        self.val_rank_ic_max = -100
        self.delta = delta
        self.best_model = None
        self.current_avg_model = None
        self.save_path = save_path
        # For averaging
        self.avg_epochs = avg_epochs
        self.param_queue = deque(maxlen=avg_epochs)

    def update(self, model):
        self.param_queue.append(copy.deepcopy(model.state_dict()))

        avg_state = {}
        for key in self.param_queue[0].keys():
            avg_state[key] = sum(state[key] for state in self.param_queue) / len(self.param_queue)
        model.load_state_dict(avg_state)
    
    
    def __call__(self, val_rank_ic, model, epoch):
        # Store current model state
        

        score = val_rank_ic
        if self.val_rank_ic_max < 0:
            self.val_rank_ic_max = val_rank_ic
            self.best_model = copy.deepcopy(model.state_dict())
        elif score <= self.val_rank_ic_max:
            self.counter += 1
            if self.verbose:
                print(f'EarlyStopping counter: {self.counter} out of {self.patience}')
            if self.counter >= self.patience:
                self.early_stop = True
        else:
            if score > self.val_rank_ic_max:
                # Update the best model and the minimum validation loss
                last = self.val_rank_ic_max
                self.val_rank_ic_max = val_rank_ic
                self.best_model = copy.deepcopy(model.state_dict())
                logging.info("Updated Mean Rank IC Model!")
                torch.save(
                    {"state_dict":model.state_dict(), 
                     "epoch":epoch, 
                     "best_ic":self.val_rank_ic_max}, 
                    self.save_path)
                if self.verbose:
                    print(f'Test rank IC increased: ({last:.6f} --> {val_rank_ic:.6f}). Saving model ...')
                
            self.counter = 0  # Reset the counter when there is improvement

        # Restore the latest model state
        model.load_state_dict(self.param_queue[-1])


class ConfigObject:
    def __init__(self, dictionary):
        for key, value in dictionary.items():
            if isinstance(value, dict):
                # 如果值是字典，再次调用此类将其转换为对象
                value = ConfigObject(value)
            self.__dict__[key] = value

    def __len__(self):
        return len(self.__dict__)

    def __str__(self) -> str:
        # 改进的打印方法，递归打印配置项
        def _str(obj, indent=0):
            result = ""
            for key, value in obj.__dict__.items():
                result += '    ' * indent + str(key) + ': '
                if isinstance(value, ConfigObject):
                    result += '\n' + _str(value, indent + 1)
                else:
                    result += str(value) + '\n'
            return result
        return _str(self)

    def __iter__(self):
        # 返回一个迭代器，遍历配置项
        for key, value in self.__dict__.items():
            yield (key, value)
            
            
def load_config(filepath):
    # 从 YAML 文件加载配置
    with open(filepath, 'r') as file:
        config_dict = yaml.safe_load(file)
        return ConfigObject(config_dict)
    
def get_config(config_name):
    with open(config_name) as f:
        config = yaml.load(f, Loader=yaml.FullLoader)
    return config

def get_model(configs, training_mode = True, use_adv = False):
    if configs.model_type == 'multi_freq':
        if training_mode:
            _, model_day, _ = get_single_model(configs.model_day, training_mode = training_mode, use_adv = use_adv)
            _, model_min, _ = get_single_model(configs.model_min, training_mode = training_mode, use_adv = use_adv)
        else:
            model_day = get_single_model(configs.model_day, training_mode = training_mode, use_adv = use_adv)
            model_min = get_single_model(configs.model_min, training_mode = training_mode, use_adv = use_adv)
        best_ic = 0
        num_epoch = 0
        model = DAY_MIN_Model(model_day, model_min, configs.output_size)
    else:
        if training_mode:
            num_epoch, model, best_ic = get_single_model(configs, training_mode = training_mode, use_adv = use_adv)
        else:
            model = get_single_model(configs, training_mode = training_mode, use_adv = use_adv)
            best_ic = 0
            num_epoch = 0
    return num_epoch, model, best_ic
def get_single_model(config, training_mode = True, use_adv = False):
    if config.model_type in ['GRU', 'gru', 'Gru']:
        model = GRUBNFCNet(
            input_features = config.input_size,
            gru_hidden_size=config.hidden_size,
            num_layers=config.num_layers,
            fc_out_features=config.output_size,
            use_sigmoid=config.use_sigmoid
        )
    elif config.model_type in ['BiAGRU', 'biagru', 'Biaru']:
        model = BiAGRU(
            input_features = config.input_size,
            gru_hidden_size=config.hidden_size,
            num_layers=config.num_layers,
            fc_out_features=config.output_size,
            use_sigmoid=config.use_sigmoid
        )
    elif config.model_type in ['LSTM', 'lstm', 'Lstm']:
        model = LSTMModel(
            input_size = config.input_size,
            hidden_size=config.hidden_size,
            output_size=config.output_size,
            num_layers = config.num_layers,
            dropout = config.dropout
        )

    elif config.model_type in ['ModernTCN', 'moderntcn']:
        model = ModernTCN(
            M = config.input_size,
            L = config.number_of_days,
            T = config.output_size,
            D = config.dimension,
            P = config.patch,
            S = config.S,
            kernel_size=config.kernel_size,
            r=config.r,
            num_layers=config.num_layers
        )
        
    elif config.model_type in ['TCN', 'tcn']:
        model = TCN(
            input_size = config.input_size,
            output_size = config.output_size,
            num_channels = config.num_channels,
            kernel_size=config.kernel_size,
            dropout=config.dropout
        )
    elif config.model_type in ['WaveNet', 'wavenet']:
        model = WaveNetModel(
            in_channels = config.input_size,
            residual_channels = config.residual_channels,
            skip_channels = config.skip_channels,
            num_blocks = config.num_blocks,
            num_layers = config.num_layers,
            output_features = config.output_size,
        )
    elif config.model_type in ['gru_sl']:
        model = GRUBNFCNet_sl(
            input_features = config.input_size,
            gru_hidden_size=config.hidden_size,
            num_layers=config.num_layers,
            fc_out_features=config.output_size
        )
    elif config.model_type in ['agru','Agru','AGRU']:
        model = AGRUModel(
            input_features = config.input_size,
            gru_hidden_size=config.hidden_size,
            num_layers=config.num_layers,
            fc_out_features=config.output_size
        )
    elif config.model_type in ['TabNet','tabnet','TABNET']:
        model = SimplifiedTabNet(
            input_dim = config.input_dim,
            output_dim = config.output_dim,
            seq_len=config.seq_len,
            n_steps=config.n_steps,
        )
    
    elif config.model_type in ['HIST', 'hist']:
        model = HISTModel(
            input_dim = config.input_dim,
            d_model = config.d_model,
            num_heads = config.num_heads,
            d_ff = config.d_ff,
            num_layers = config.num_layers,
            output_dim = config.output_dim,
            seq_len = config.seq_len
        )
    elif config.model_type in ['iTransformer', 'itransformer']:
        model = iTransformer(seq_len=config.seq_len,
                             pred_len=config.output_size,
                             output_attention=config.output_attention,
                             input_size = config.input_size,
                             use_norm=config.use_norm,
                             d_model=config.d_model,
                             d_ff=config.d_ff,
                             n_heads = config.n_heads,
                             e_layers=config.e_layers,
                             dropout=config.dropout,
                             activation=config.activation)
    
    elif config.model_type in ['multgru']:
        model = MultiScaleRNN(input_size=config.input_size,
                              seq_len=config.seq_len,
                              hidden_size=config.hidden_size,
                              num_layers=config.num_layers,
                              dropout=config.dropout,
                              scales=config.scales,
                              )
    elif config.model_type in ['transformer']:
        model = Transformer(input_size=config.input_size,
                            d_model=config.d_model,
                            nhead=config.nhead,
                            num_layers=config.num_layers,
                            output_size=config.output_size,
                            dropout=config.dropout,
                            )
    elif config.model_type in ['mamba', 'Mamba']:
        model_args = ModelArgs(
            input_size=config.input_size,
            output_size=config.output_size,
            d_model=config.d_model,
            n_layer=config.n_layer,
            d_state=config.d_state,
            expand=config.expand,
            dt_rank=config.dt_rank,
            d_conv=config.d_conv,
            conv_bias=config.conv_bias,
            bias=config.bias
        )
        model = Mamba(model_args)
    elif config.model_type in ['master', 'MASTER']:
        model = MASTER(d_feat=config.input_size,
                       d_model=config.d_model,
                       t_nhead=config.t_nhead,
                       s_nhead=config.s_nhead,
                       T_dropout_rate=config.T_dropout_rate,
                       S_dropout_rate=config.S_dropout_rate,
                       output_size=config.output_size)
    else:
        raise ValueError(f"no such Model {config.model_type}")
    
    if 'adv' in config.__dict__.keys():
        adv_plugin = RevGrad(config.adv.gamma, config.adv.gamma_clip)
        model = Alpha_Factor_Model(base_model=model, rev_grad=adv_plugin)
    
    if config.resume_from:
        logging.info("Loading checkpoint ... ...")
        saved_dict = torch.load(config.resume_from)
        num_epoch = saved_dict['epoch']
        state_dict = saved_dict['state_dict']
        try:
            best_ic = saved_dict['best_ic']
        except:
            best_ic = 0
        model.load_state_dict(state_dict)
    else:
        num_epoch = 0
        best_ic = 0
    
    
    
    if training_mode:
        return num_epoch, model, best_ic
    else: return model
        
    

def get_optimizer(config, model):
    # 获取优化器的名称
    optimizer_name = config.TrainingArguments.optimizer.name.lower()

    # 获取学习率
    lr = config.TrainingArguments.optimizer.learning_rate

    # 根据优化器的名称创建相应的优化器对象
    if optimizer_name == 'adam':
        optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    elif optimizer_name == 'adamw':
        optimizer = torch.optim.AdamW(model.parameters(), lr=lr)
    elif optimizer_name == 'sgd':
        # 对于SGD，通常需要一个额外的momentum参数
        momentum = config.TrainingArguments.optimizer.momentum
        optimizer = torch.optim.SGD(model.parameters(), lr=lr, momentum=momentum)
    elif optimizer_name == 'rmsprop':
        # 对于RMSprop，可能需要alpha和momentum参数
        alpha = config.TrainingArguments.optimizer.alpha
        momentum = config.TrainingArguments.optimizer.momentum
        optimizer = torch.optim.RMSprop(model.parameters(), lr=lr, alpha=alpha, momentum=momentum)
    else:
        raise ValueError(f"Unsupported optimizer type: {optimizer_name}, if needed contact Chaozheng Wang")

    return optimizer


def get_lr_scheduler(optimizer, config):
    from torch.optim.lr_scheduler import StepLR, ExponentialLR, CosineAnnealingLR
    scheduler = config.TrainingArguments.lr_scheduler.name
    
    if scheduler == 'step':
        # 创建 StepLR 调度器
        scheduler = StepLR(optimizer, step_size=config.TrainingArguments.lr_scheduler.step_size, gamma=config.TrainingArguments.lr_scheduler.gamma)
    elif scheduler == 'exponential':
        # 创建 ExponentialLR 调度器
        scheduler = ExponentialLR(optimizer, gamma=config.TrainingArguments.lr_scheduler.gamma)
    elif scheduler == 'cosine':
        # 创建 CosineAnnealingLR 调度器
        scheduler = CosineAnnealingLR(optimizer, T_max=config.epoch)
    elif scheduler is None:
        return None
    else:
        raise ValueError(f'Unknown lr_scheduler: {scheduler}')

    return scheduler




if __name__ == '__main__':
    config = load_config('configs/gru_example.yaml')
    print(config.TrainingArguments.lr_scheduler)