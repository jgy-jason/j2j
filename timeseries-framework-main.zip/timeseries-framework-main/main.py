import torch
import torch.optim as optim
from torch.optim import lr_scheduler
from torch.utils.data import DataLoader
from dataset import *
from utils import *
from losses import My_Loss, CustomLoss
from trainer import *
import argparse
import logging


def parse_arguments():
    # 创建 ArgumentParser 对象
    parser = argparse.ArgumentParser(description='Parse command line arguments.')

    # 添加 output_dir 参数，指定类型为字符串，默认值为当前目录
    parser.add_argument('--output_dir', type=str, default='./ckpt_new',
                        help='Directory where the output files will be saved.')

    # 添加 log_dir 参数，指定类型为字符串，默认值为当前目录
    parser.add_argument('--log_dir', type=str, default='./logs',
                        help='Directory where the log files will be saved.')

    # 添加 config_name 参数，指定类型为字符串，没有提供默认值
    parser.add_argument('--training_config', type=str, default='./configs/gru_example.yaml',
                        help='Name of the training configuration file.')
    
    parser.add_argument('--data_config', type=str, default='./configs/data_config_timeseries_3d.yaml',
                        help='Name of the data configuration file.')

    # 解析命令行参数
    args = parser.parse_args()

    return args

# import warnings
# warnings.filterwarnings("ignore")




# 5. 训练模型

if __name__ == '__main__':
    args = parse_arguments()
    
    training_config = load_config(args.training_config)
    data_config = load_config(args.data_config)
    
    if training_config.seed:
        set_seed(training_config.seed)
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    console_handler.setFormatter(console_formatter)

    # 配置日志输出到文件
    file_handler = logging.FileHandler(f'{args.log_dir}/{training_config.log_name}.log', mode='a')
    file_handler.setLevel(logging.INFO)
    file_formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    file_handler.setFormatter(file_formatter)

    # 获取根日志器，并添加上面定义的两个处理器
    logging.getLogger().addHandler(console_handler)
    logging.getLogger().addHandler(file_handler)
    logging.getLogger().setLevel(logging.INFO)

    
    logging.info("reading data ... ...")
    logging.info(f"the training config is {training_config}")
    logging.info(f"the data config is {data_config}")
    if data_config.data_type == 'multi_freq':
        (train_data_loader1, train_data_loader2, train_data_loader3, valid_data_loader1, valid_data_loader2,
         valid_data_loader3, test_data_loader1, test_data_loader2, test_data_loader3) = get_loader(data_config)
    else:
        train_loader, valid_loader, test_loader = get_loader(data_config)
    
    num_epoch, model, Best_eval_IC = get_model(training_config.ModelTraining)
    optimizer = get_optimizer(training_config, model)
    scheduler = get_lr_scheduler(optimizer, training_config)
    custom_loss = My_Loss(training_config)
    # if 'adv' in training_config.ModelTraining.__dict__.keys():
    #     use_adv = True
    # else:
    #     use_adv = False
    
    if torch.cuda.is_available():
        model = model.cuda()

    Best_eval_loss = 100
    no_improvement = 0
    if training_config.moving_average:
        early_stop_machine = EarlyStopping(patience=training_config.TrainingArguments.early_stop.patience, verbose=True,
                                           avg_epochs=5, save_path=f'{args.output_dir}/{training_config.log_name}_best_ic_{training_config.ModelTraining.model_type}_MA.bin')
    else:
        early_stop_machine = None
    if data_config.data_type == 'mult_freq':
        trainer = Trainer_mult(model=model,
                          num_epoch=training_config.epoch,
                          train_loader1=train_data_loader1,
                          train_loader2=train_data_loader2,
                          train_loader3=train_data_loader3,
                          valid_loader1=valid_data_loader1,
                          valid_loader2=valid_data_loader2,
                          valid_loader3=valid_data_loader3,
                          test_loader1=test_data_loader1,
                          test_loader2=test_data_loader2,
                          test_loader3=test_data_loader3,
                          optimizer=optimizer,
                          shceduler=scheduler,
                          custom_loss=custom_loss,
                          config=training_config,
                          early_stop_machine=early_stop_machine)
    else:
        trainer = Trainer(model=model,
                        num_epoch=training_config.epoch,
                        train_loader=train_loader,
                        valid_loaader=valid_loader,
                        test_loader=test_loader,
                        optimizer=optimizer,
                        shceduler=scheduler,
                        custom_loss=custom_loss,
                        config=training_config,
                        early_stop_machine=early_stop_machine)
    trainer.train(args, Best_eval_IC, num_epoch)
