import torch
import torch.nn as nn
import torch.nn.functional as F

class Attention(nn.Module):
    def __init__(self, gru_hidden_size):
        super(Attention, self).__init__()
        self.attention_fc = nn.Linear(2 * gru_hidden_size, 1)

    def forward(self, x):
        # x 的形状: [B, seq_length, 2 * gru_hidden_size] (因为是双向)
        attention_weights = self.attention_fc(x).squeeze(2)
        attention_weights = F.softmax(attention_weights, dim=1)
        
        # 应用注意力权重
        attention_weights = attention_weights.unsqueeze(2)
        weighted_gru_output = x * attention_weights

        # 求和加权输出
        weighted_sum = torch.sum(weighted_gru_output, dim=1)
        return weighted_sum

class BiAGRU(nn.Module):
    def __init__(self, input_features=7, gru_hidden_size=128, num_layers=1, fc_out_features=64, use_sigmoid=True):
        super(BiAGRU, self).__init__()
        self.gru = nn.GRU(input_size=input_features, hidden_size=gru_hidden_size, num_layers=num_layers, batch_first=True, bidirectional=True)
        self.attention = Attention(gru_hidden_size)
        self.bn = nn.BatchNorm1d(2 * gru_hidden_size)  # 注意特征维度加倍
        self.fc = nn.Linear(2 * gru_hidden_size, fc_out_features)  # 输入特征维度加倍
        self.use_sigmoid = use_sigmoid
        
    def forward(self, x):

        x = torch.squeeze(x, 0)
        x = x.float()
        # print(x.shape)
        # x = x.permute(0, 2, 1)
        x, _ = self.gru(x)  # x is of shape (B, seq_length, 2 * gru_hidden_size)

        # 应用注意力机制
        x = self.attention(x)  # x is now of shape (B, 2 * gru_hidden_size)

        # 应用批量归一化
        x = self.bn(x)

        # 应用全连接层和可选的 Sigmoid 激活函数
        if self.use_sigmoid:
            x = torch.sigmoid(self.fc(x))
        else:
            x = self.fc(x)
        return x


if __name__ == '__main__':
    model = BiAGRU(7, 128, 64)
    X = torch.ones((5000, 7, 63))
    Y = model(X)
    print(Y.shape)