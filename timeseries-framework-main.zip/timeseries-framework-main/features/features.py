import numpy as np
import pandas as pd
import h5py

dates = pd.date_range('2020-01-01', '2020-12-31', freq='D').strftime('%Y%m%d').astype(int)  # 2020年全年的日期
times = [930, 1200, 1430, 1600]  # 日内四个时间点
instruments = [i for i in range(60000,60200)]  # 200只股票
index = pd.MultiIndex.from_product([dates, times, instruments], names=['level_0', 'level_1', 'level_2'])
data = np.random.randn(len(index), 20)
percentage_to_mask = 0.25

num_values_to_mask = int(data.size * percentage_to_mask)
np.random.seed(42)  # For reproducibility
indices_to_mask = np.random.choice(data.size, num_values_to_mask, replace=False)

data.ravel()[indices_to_mask] = np.nan
df = pd.DataFrame(data, index=index, columns=[f'feature{i+1}' for i in range(20)]).reset_index()
print(df)

data = np.array(df.iloc[:, 3:])
data_new = data.reshape(int(data.shape[0] / 200), 200, data.shape[1])
dates = np.array(df['level_0']).reshape(int(data.shape[0] / 200), 200)
times = np.array(df['level_1']).reshape(int(data.shape[0] / 200), 200)
with h5py.File('data/factor_f240min_p15min_20240117.h5', 'a') as f:
    f.create_dataset('dates', data=dates)
    f.create_dataset('times', data=times)
    f.create_dataset('codes', data=np.array(instruments))

df = df.drop(columns=['level_0', 'level_1', 'level_2'])
print(df)
# df['valid_index'] = df.isna().all(axis=1).astype(int)
df['valid_index'] = (df.isna().sum(axis=1) >= 10).astype(int)
df['valid_index'] = 1 - df['valid_index']
print(df)

valid_index = np.array(df['valid_index']).reshape(int(data.shape[0] / 200), 200)
print((valid_index==1).sum())
with h5py.File('data/factor_f240min_p15min_20240117.h5', 'a') as f:
    f.create_dataset('valid_index', data=valid_index)

df = df.drop(columns=['valid_index'])

with h5py.File('data/factor_f240min_p15min_20240117.h5', 'a') as f:
    f.create_dataset('alpha_name', data=np.array(df.columns))

total_rows, total_cols = df.shape
with h5py.File('data/factor_f240min_p15min_20240117.h5', 'a') as f:
    data_set = f.create_dataset('data', data=data_new, dtype='float32')
