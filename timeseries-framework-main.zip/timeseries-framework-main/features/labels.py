import numpy as np
import pandas as pd
import h5py

dates = pd.date_range('2020-01-01', '2020-12-31', freq='D').strftime('%Y%m%d').astype(int)  # 2020年全年的日期
times = [930, 1200, 1430, 1600]  # 日内四个时间点
instruments = [i for i in range(60000,60200)]  # 200只股票
index = pd.MultiIndex.from_product([dates, times, instruments], names=['level_0', 'level_1', 'level_2'])
data = np.random.randn(len(index), 1)
df = pd.DataFrame(data, index=index, columns=[f'label{i+1}' for i in range(1)]).reset_index()
print(df)

data = np.array(df.iloc[:, 3:])
data_new = data.reshape(int(data.shape[0] / 200), 200)
with h5py.File('data/factor_f240min_p15min_20240117.h5', 'a') as f:
    data_set = f.create_dataset('close2close', data=data_new, dtype='float32')