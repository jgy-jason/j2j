from dataset_timeseries_3d import *
from torch.utils.data import DataLoader
import logging

def get_timeseries_data(data_config, data_type = ["train", "valid", "test"]):
    
    training_set = H5_Dataset_30min_backNd_time_6_3d(h5_path=data_config.h5_path,window_size=data_config.window_size,
        train_start_date=data_config.train_test_split.train_start_date,train_end_date=data_config.train_test_split.train_end_date,
        valid_start_date=data_config.train_test_split.valid_start_date,valid_end_date=data_config.train_test_split.valid_end_date,
        test_start_date=data_config.train_test_split.test_start_date,test_end_date=data_config.train_test_split.test_end_date,
        label=data_config.label,lazy_load=data_config.lazy_load,flag='train',alpha_names=data_config.alpha_names
    )
    valid_set = H5_Dataset_30min_backNd_time_6_3d(h5_path=data_config.h5_path,window_size=data_config.window_size,
        train_start_date=data_config.train_test_split.train_start_date,train_end_date=data_config.train_test_split.train_end_date,
        valid_start_date=data_config.train_test_split.valid_start_date,valid_end_date=data_config.train_test_split.valid_end_date,
        test_start_date=data_config.train_test_split.test_start_date,test_end_date=data_config.train_test_split.test_end_date,
        label=data_config.label,lazy_load=data_config.lazy_load,flag='valid',alpha_names=data_config.alpha_names
    )
    test_set = H5_Dataset_30min_backNd_time_6_3d(h5_path=data_config.h5_path,window_size=data_config.window_size,
        train_start_date=data_config.train_test_split.train_start_date,train_end_date=data_config.train_test_split.train_end_date,
        valid_start_date=data_config.train_test_split.valid_start_date,valid_end_date=data_config.train_test_split.valid_end_date,
        test_start_date=data_config.train_test_split.test_start_date,test_end_date=data_config.train_test_split.test_end_date,
        label=data_config.label,lazy_load=data_config.lazy_load,flag='test',alpha_names=data_config.alpha_names
    )
    output = []
    if "train" in data_type:
        output.append(training_set)
    if "valid" in data_type:
        output.append(valid_set)
    if "test" in data_type:
        output.append(test_set)
    return output


def get_loader(data_config, mode = 'train'):
    if data_config.freq == 'interday':
        if data_config.data_type == 'min_ts': 
            max_num_workers = torch.get_num_threads()
            print(f"cpu:{max_num_workers}")
            train_set, valid_set, test_set = get_timeseries_data(data_config, data_type=["train", "valid", "test"])

            train_sampler = DateSampler(train_set)
            train_loader = DataLoader(train_set, batch_sampler=train_sampler, pin_memory=True, num_workers=max_num_workers)
            
            valid_sampler = DateSampler(valid_set)
            valid_loader = DataLoader(valid_set, batch_sampler=valid_sampler, pin_memory=True, num_workers=max_num_workers)
            
            test_sampler = DateSampler(test_set)
            test_loader = DataLoader(test_set, batch_sampler=test_sampler, pin_memory=True, num_workers=max_num_workers)

            return train_loader, valid_loader, test_loader
    else:
        raise ValueError(f"Expected data type: interday, but received {data_config.data_type}")


    
if __name__ == "__main__":
    # import pandas as pd

    # data = pd.read_pickle("63_day_data_after_filtering.pkl")
    # print(data.loc['2023-12-05'])
    config = load_config("configs/data_config_day_factor.yaml")
    
    df = pd.read_pickle(config.factor_data_path)

    # df = load_data(config)
    valid_data, test_data = get_day_factor_data(config, df, ['test', 'valid'])
    from torch.utils.data import DataLoader
    loader = DataLoader(test_data, batch_size=1, shuffle=False, num_workers=16)
    # print(test_data[349])
    for (features, targets, today, able_instrument) in tqdm(loader):
        pass