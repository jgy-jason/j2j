import pandas as pd

# 示例因子数据
factor_data = pd.DataFrame({
    'date': ['2023-01-01', '2023-01-01', '2023-01-02', '2023-01-02'],
    'group': ['A', 'B', 'A', 'B'],
    'factor': [1.0, 2.0, 3.0, 4.0]
})

# 设置多重索引
factor_data.set_index(['date', 'group'], inplace=True)

# 是否进行多空对冲
is_long_short = True

# 是否进行分组调整
group_adjust = True

# 计算权重
grouper = [factor_data.index.get_level_values('date')]
if group_adjust:
    grouper.append('group')

def to_weights(group, is_long_short):
        if is_long_short:
            demeaned_vals = group - group.mean()
            return demeaned_vals / demeaned_vals.abs().sum()
        else:
            return group / group.abs().sum()
        
weights = factor_data.groupby(grouper)['factor'] \
    .apply(to_weights, is_long_short)

print(weights)