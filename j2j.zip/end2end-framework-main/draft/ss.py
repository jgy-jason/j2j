def num_to_letters(s):
    result = []
    
    def backtrack(index, path):
        if index == len(s):
            result.append(''.join(path))
            return
        

        if 1 <= int(s[index]) <= 9:  # 1-9 对应 a-i
            backtrack(index + 1, path + [chr(int(s[index]) + ord('a') - 1)])
        

        if index + 1 < len(s) and 10 <= int(s[index:index+2]) <= 26:  # 10-26 对应 j-z
            backtrack(index + 2, path + [chr(int(s[index:index+2]) + ord('a') - 1)])
    
    backtrack(0, [])
    return result
print(num_to_letters('123'))