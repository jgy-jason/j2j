def ArrayChallenge(strArr):

    matrix = [list(row) for row in strArr]
    
    start_x, start_y = None, None
    enemies = []
    
    for r in range(len(matrix)):
        for c in range(len(matrix[r])):
            if matrix[r][c] == '1':
                start_x, start_y = r, c
            elif matrix[r][c] == '2':
                enemies.append((r, c))
    
    # If there are no enemies (no '2's), return 0
    if not enemies:
        return 0

    def calculate_distance(x1, y1, x2, y2):
        horiz_dist = min(abs(y1 - y2), len(matrix[0]) - abs(y1 - y2))
        vert_dist = min(abs(x1 - x2), len(matrix) - abs(x1 - x2))
        return horiz_dist + vert_dist
    
    min_distance = float('inf')
    for ex, ey in enemies:
        dist = calculate_distance(start_x, start_y, ex, ey)
        min_distance = min(min_distance, dist)
    
    return min_distance

strArr = ["0000", "1000", "0002", "0002"]
print(ArrayChallenge(strArr))