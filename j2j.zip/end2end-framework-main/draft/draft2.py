import pandas as pd
import numpy as np
import torch
from scipy import stats
df = pd.read_pickle('data/day/423_factor_data_raw.pkl')

def rm_nan(v1, v2):
    assert v1.ndim == 1 and v2.ndim == 1
    idx = ~np.isnan(v1) & ~np.isnan(v2)
    v1 = v1[idx]
    v2 = v2[idx]
    return v1, v2


def zscore(y, eps=1e-6):
    y = (y - torch.mean(y)) / (torch.std(y) + eps) 
    return y

def IC(y_pred, y_true):
    y_pred, y_true = rm_nan(y_pred, y_true)
    if len(y_pred) >= 100:
        return np.corrcoef(y_pred, y_true)[0, 1]
    else:
        return np.nan
    
def RankIC(y_pred, y_true):
    y_pred, y_true = rm_nan(y_pred, y_true)
    if len(y_pred) >= 100:
        return stats.spearmanr(y_pred, y_true)[0]
    else:
        return np.nan

df = df[['DATE','$f_5min_return_mean_adj_umr','$f_5min_return_mean_cross_section_umr']]
daily_ic = df.groupby('DATE').apply(lambda x: IC(x['$f_5min_return_mean_adj_umr'].values, x['$f_5min_return_mean_cross_section_umr'].values))
average_ic = daily_ic.mean()


df = df[['$f_5min_return_mean_adj_umr','$f_5min_return_mean_cross_section_umr',]]
corr = IC(df['Close'].values, df['Open'].values)
corr