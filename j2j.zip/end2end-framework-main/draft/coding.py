import torch
import torch.nn as nn
import torch.nn.functional as F
features=10

x = torch.randn(features)

class n1(nn.Module):
    def __init__(self):
        super(n1, self).__init__()
        self.fc1 = nn.Linear(features, 5)
        self.fc2 = nn.Linear(5, 1)
    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = self.fc2(x)
        return x
class dataset(torch.utils.data.Dataset):
    def __init__(self):
        self.data = torch.randn(100, features)
        self.target = torch.randn(100)
    def __len__(self):
        return len(self.data)
    def __getitem__(self, idx):
        return self.data[idx], self.target[idx]
    
class dataloader(torch.utils.data.DataLoader):
    def __init__(self, dataset, batch_size):
        super(dataloader, self).__init__(dataset, batch_size=batch_size, shuffle=True)


