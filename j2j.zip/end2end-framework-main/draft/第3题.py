from datetime import datetime
import numpy as np 
def days_between_dates(date1, date2):
    # 将字符串日期转换为datetime对象
    d1 = datetime.strptime(date1, "%Y-%m-%d")
    d2 = datetime.strptime(date2, "%Y-%m-%d")
    
    # 计算两个日期之间的差值
    delta = np.abs(d2 - d1)
    
    # 返回相差的天数
    return delta.days

# 示例
date1 = "2024-01-05"
date2 = "2024-01-06"
print(days_between_dates(date1, date2))  # 输出：1

date1 = "2019-02-22"
date2 = "2018-12-24"
print(days_between_dates(date1, date2))  # 输出：60