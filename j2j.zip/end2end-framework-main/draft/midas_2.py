import numpy as np
import pandas as pd
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras import optimizers
from tensorflow.keras.losses import MeanSquaredError

# 1. 读取数据并将特征转换为 NumPy 数组
# 假设 CSV 文件名为 'abalone.csv'，并且数据已经准备好了
data = pd.read_csv('abalone.csv')

# 假设数据集中的最后一列是目标变量（即年龄），
# 其他列为特征变量
abalone_features = data.iloc[:, :-1].values  # 提取特征
abalone_target = data.iloc[:, -1].values     # 提取目标变量

# 2. 创建模型：使用 Sequential 模型和两个 Dense 层
model = Sequential()

# 第一层：Dense 层，64 个神经元，激活函数使用默认的 'linear' 激活
model.add(Dense(64, input_dim=abalone_features.shape[1], activation='relu'))

# 第二层：Dense 层，1 个神经元，因为预测的是连续值（年龄）
model.add(Dense(1))

# 3. 编译模型：使用 MeanSquaredError 损失函数和 Adam 优化器
model.compile(loss=MeanSquaredError(), optimizer=optimizers.Adam())

# 4. 训练模型：epochs=10，verbose=0
history = model.fit(abalone_features, abalone_target, epochs=10, verbose=0)

# 5. 打印训练历史和模型概况
print("Training History:")
print(history.history)

# 打印模型概况
print("\nModel Summary:")
model.summary()
