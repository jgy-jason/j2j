import torch

# 设置随机种子
torch.manual_seed(0)

# 创建 5x5 的张量，随机初始化，值在 -1 到 1 之间
tensor = torch.rand(5, 5) * 2 - 1  # 将值映射到 -1 到 1 之间

# 计算奇异值分解（SVD）
U, S, V = torch.svd(tensor)

# 计算特征值（即奇异值的平方）
eigenvalues = S**2

# 打印特征值（即奇异值的平方）
print(eigenvalues)

# 将特征值转换为 Python 列表并打印
eigenvalues_list = eigenvalues.tolist()
print(eigenvalues_list)
