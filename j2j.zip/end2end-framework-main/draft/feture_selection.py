import numpy as np
import pandas as pd

# 设置随机种子和样本大小
np.random.seed(42)
num_assets = 10  # 资产数量
num_days = 100  # 时间序列长度

# 生成随机的价格数据 (模拟股票价格)
prices = np.cumprod(1 + np.random.normal(0, 0.01, (num_days, num_assets)), axis=0) * 100
returns = np.diff(prices, axis=0) / prices[:-1]  # 日收益率

# 构建时序因子
def calculate_time_series_factors(prices, returns):
    factors = {}
    # 动量因子（过去20天的价格变化）
    factors['momentum'] = prices[-1, :] - prices[-21, :]
    # 波动率因子（过去20天收益率波动）
    factors['volatility'] = np.std(returns[-20:, :], axis=0)
    # MACD因子
    ema_fast = pd.DataFrame(prices).ewm(span=12).mean().values
    ema_slow = pd.DataFrame(prices).ewm(span=26).mean().values
    factors['macd'] = ema_fast[-1, :] - ema_slow[-1, :]
    # 趋势强度因子（价格变化的平滑比率）
    delta_prices = np.diff(prices, axis=0)
    factors['trend_strength'] = np.sum(delta_prices[-20:, :] > 0, axis=0) / 20
    # 资金流因子（模拟为价格变化乘以成交量）
    volume = np.random.randint(1000, 10000, size=(num_days, num_assets))
    factors['money_flow'] = np.sum(delta_prices[-20:, :] * volume[-20:, :], axis=0)
    return pd.DataFrame(factors)

# 构建截面因子
def calculate_cross_sectional_factors():
    factors = {}
    # 市净率因子
    factors['book_to_market'] = np.random.uniform(0.5, 1.5, num_assets)
    # 市盈率因子
    factors['price_to_earnings'] = np.random.uniform(10, 30, num_assets)
    # 股息率因子
    factors['dividend_yield'] = np.random.uniform(0.01, 0.05, num_assets)
    # 收益修正因子（模拟预测增长率）
    factors['earnings_revision'] = np.random.uniform(-0.1, 0.1, num_assets)
    # 流动性因子
    factors['liquidity'] = np.random.uniform(0.1, 1.0, num_assets)
    return pd.DataFrame(factors)

# 生成时序因子
time_series_factors = calculate_time_series_factors(prices, returns)
# 生成截面因子
cross_sectional_factors = calculate_cross_sectional_factors()

# 合并因子
combined_factors = pd.concat([time_series_factors, cross_sectional_factors], axis=1)

# 生成目标变量 y (组合因子权重为0.5:0.5)
weights_time = 0.5
weights_cross = 0.5
y = (
    weights_time * time_series_factors.mean(axis=1).values +
    weights_cross * cross_sectional_factors.mean(axis=1).values
)

# 输出样本
combined_factors['y'] = y

# 查看因子数据
import ace_tools as tools; tools.display_dataframe_to_user(name="因子样本数据", dataframe=combined_factors)
