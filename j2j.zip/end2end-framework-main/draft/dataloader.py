import numpy as np
import pandas as pd
import datetime
import tushare as ts

pro = ts.pro_api('20240522230128-416daccb-20db-49d0-89ea-d983d88c9b04')
pro._DataApi__http_url = 'http://tsapi.majors.ltd:7000'

begin = datetime.date(2020, 1, 1)
end = datetime.date(2023, 12, 31)
delta = datetime.timedelta(days=1)
df = pd.DataFrame()
while begin <= end:
   date_str = begin.strftime("%Y%m%d")
   daily_data = pro.daily(start_date=date_str, end_date=date_str)
   df = pd.concat([df, daily_data], ignore_index=True)
   begin += delta

df.to_pickle('E:/data/stock_data_daily.pkl', index=False)