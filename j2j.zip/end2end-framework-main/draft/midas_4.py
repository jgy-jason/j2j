def ArrayChallenge(arr):
    # Step 1: Perform the circular rotation
    N = arr[0]  # The first element tells us the rotation start index
    rotated_arr = arr[N:] + arr[:N]
    
    # Step 2: Convert the rotated array to a string
    rotated_str = ''.join(map(str, rotated_arr))
    
    # Step 3: Remove characters from the ChallengeToken
    challenge_token = "swift03pec7"
    challenge_set = set(challenge_token.lower())  # Set for case-insensitive lookup
    final_str = ''.join([ch for ch in rotated_str if ch.lower() not in challenge_set])
    
    # Step 4: Return the result or 'EMPTY' if the final string is empty
    return final_str if final_str else "EMPTY"

# Test cases
print(ArrayChallenge([3, 2, 1, 6]))  # Output: 621
print(ArrayChallenge([4, 3, 4, 3, 1, 2]))  # Output: 1244
