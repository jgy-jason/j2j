from scipy.stats import zscore
from torch.utils.data import Dataset
import pandas as pd
import numpy as np
# from data_process import datas,load_factors,align_datas,split_factors,join_factors
# from data_process import data_filter,data_fillna,winsorize,normalization
# from dataset import *
from tqdm import tqdm
from utils import load_config
import warnings

class Day_Factor_new(Dataset):
    def __init__(self, data_frame_x, data_frame_y, fields,
                 train_start, train_end,
                 valid_start, valid_end,
                 test_start, test_end, 
                 mode="train", T=63, H=2, label_type="open2open", label_weight=1, pct = True):
        self.fields = fields
        self.data_frame_x = data_frame_x
        self.data_frame_y = data_frame_y
        self.label_weight = label_weight
        # self.data1 = {f:test_data.pivot_table(index='datetime', columns='instrument', values=f) for f in self.fields} # 每一天 每一支股票的属性
        self.H = H
        self.T = T
        self.pct = pct
        self.label_type = label_type
        self.mode = mode
            
        ### self.df_able_instrument=self.get_able_instrument(self.data_frame_y['close'].unstack().sort_index(), self.T + self.H + 1).shift(- (self.H + 1))
        self.df_able_instrument=self.get_able_instrument(self.data_frame_y['close'].unstack().sort_index(), self.T + self.H + 2).shift(- (self.H + 1))
        self.df_able_instrument=self.df_able_instrument.replace(False,np.nan)
        self.all_dates=self.df_able_instrument.index
        
        pre = len(self.all_dates[self.all_dates<pd.to_datetime(train_start)])
        
        train_set_point = len(self.all_dates[(self.all_dates>=pd.to_datetime(train_start)) &
                                        (self.all_dates<pd.to_datetime(train_end))])
        valid_set_point = len(self.all_dates[(self.all_dates>=pd.to_datetime(valid_start)) & 
                                        (self.all_dates<pd.to_datetime(valid_end))])
        test_set_point = len(self.all_dates[(self.all_dates>=pd.to_datetime(test_start)) &
                                        (self.all_dates<pd.to_datetime(test_end))])
        
        after = len(self.all_dates[self.all_dates>=pd.to_datetime(test_end)])
        assert pre + train_set_point + valid_set_point + test_set_point + after == len(self.all_dates)
        
        if mode == 'train':
            self.data_range = list(range(pre+T, pre+train_set_point))
        elif mode == 'valid':
            self.data_range = list(range(pre + train_set_point, pre + train_set_point + valid_set_point))
        else:
            self.data_range = list(range(pre + train_set_point + valid_set_point, pre + train_set_point + valid_set_point + test_set_point - self.H - 1))
            # print(len(self.data_range))
        
    def get_labels(self, t, able_instrument_today):
        if ',' in self.label_weight:
            weight = [float(i) for i in self.label_weight.split(',')]
        else:
            weight = [float(self.label_weight)]
        label_dict = {}
        label_list = self.label_type.split(',')
        for label in label_list:
            if "2" in label:  # return rate 
                start_attr, end_attr = label.split('2')
                # start_attr, end_attr = '$' + start_attr, '$' + end_attr
                T_1 = self.all_dates[t + 1]
                T_H = self.all_dates[t + self.H + 1]
                label_dict[label] = (self.data_frame_y.loc[pd.MultiIndex.from_product([[T_H],able_instrument_today])].reset_index()[end_attr] / self.data_frame_y.loc[pd.MultiIndex.from_product([[T_1],able_instrument_today])].reset_index()[start_attr]) - 1
            else:
                future_days = self.all_dates[t: t+self.H+1] # H+1 days, then have H pct change
                vwap_data = self.data_frame_y.loc[pd.MultiIndex.from_product([future_days, able_instrument_today])]['$vwap']
                ret = vwap_data.groupby('instrument').pct_change()
                if label == 'sharp':
                    label_dict[label] = (ret.groupby('instrument').mean() / ret.groupby('instrument').std())*(8)**0.5
                    
                elif label == 'drawdown':
                    label_dict[label] = (vwap_data/vwap_data.groupby('instrument').expanding().max().reset_index(level=0,drop=True)).groupby('instrument').min()-1
                    
                elif label == "volatility":
                    label_dict[label] = ret.groupby('instrument').std()*(8)**0.5
        for key in label_dict.keys():
            if self.pct:
                label_dict[key] = label_dict[key].rank(pct=True).values
            else:
                label_dict[key] = label_dict[key].values
                
        # weighted sum        
        labels = list(label_dict.values())
        Y = np.zeros_like(labels[0])
        for i in range(len(labels)):
            Y += weight[i] * labels[i]
        return Y
            
    def __len__(self):
        return len(self.data_range)
    
    def __getitem__(self, index):
        t = self.data_range[index]
        
        today = self.all_dates[t]
        dates_T=self.all_dates[t - self.T + 1: t+1] # 往前找T天，（一共 T 天）
        
        able_instrument_today=self.df_able_instrument.loc[today].dropna().index
        
        start_day = self.all_dates[t - self.T + 1]
        
        X = self.data_frame_x.loc[pd.MultiIndex.from_product([dates_T,able_instrument_today])]
        # X_start = X.loc[start_day]
        # X = X / X_start.reindex(X.index.get_level_values(1)).values
        X = X.values.reshape(self.T, len(able_instrument_today),  -1).transpose(1, 2, 0).astype('float')
        
        Y = self.get_labels(t, able_instrument_today)
        
            
            
        
        debug = False
        if debug:
            if np.isnan(X).any() or np.isnan(Y).any():
                print("trigger")
            
        if self.mode in ['valid', 'test']:
            return X, Y, [str(today)], list(able_instrument_today.values.astype('str'))
        
        return X, Y
    
    def get_able_instrument(self, df, n):
        return df.rolling(n).count()==n 



# def get_filter_df(df, rule):
#     if rule == 'is_st_or_suspended':
#         return ~df.is_st_or_suspended.fillna(False)
#     elif rule == 'volume0':
#         return ~df.volume == 0
#     elif rule == 'is_new':
#         return ~df.is_new
#     elif rule == 'is_1000':
#         df['is_1000'] = df['is_1000'].astype(bool)
#         return df.is_1000
#     elif rule == 'is_2000':
#         df['is_2000'] = df['is_2000'].astype(bool)
#         return df.is_2000
#     elif rule == 'is_300':
#         df['is_300'] = df['is_300'].astype(bool)
#         return df.is_300
#     elif rule == 'is_500':
#         df['is_500'] = df['is_500'].astype(bool)
#         return df.is_500
#     else:
#         raise ValueError("Currently no such filtering rule: {}".format(rule))

# def load_factor_data(df,data_config):
#     print("loading factors ...")
    
#     #获取filter字典，并把filter字典和factor字典合并
#     total_factors = data_config.factors.copy() + data_config.apply_filter.copy()
#     load_factors(total_factors)

#     base = datas.day.close
#     new_datas=align_datas(base,dataset=datas.day,inplace=False)

#     # 选定特征进行合并
#     new_datas_df = join_factors(total_factors, new_datas)
#     #print(new_datas_df)
#     new_datas_df.index = new_datas_df.index.set_names('instrument', level=1)
#     #print(new_datas_df)
#     warnings.filterwarnings("ignore", category=pd.errors.PerformanceWarning)
#     new_df = pd.merge(df, new_datas_df, on=['datetime', 'instrument'], how='left')
#     # print(new_df)
#     # print(new_df.index.get_level_values(0).unique())
#     print("data filtering ...")
#     if data_config.apply_filter:
#         filter_criteria = None
#         for rule in data_config.apply_filter:
#             if filter_criteria is None:
#                 filter_criteria = get_filter_df(new_df, rule)
#             else:
#                 filter_criteria = filter_criteria | get_filter_df(new_df, rule)
#         new_df = new_df.loc[filter_criteria]
#         # label = ['close', 'is_2000']
#         # label = ['close', 'is_1000']
#         label = ['close', 'is_500']
#         # label = ['close', 'is_300']
#         #label = ['close']
#         new_df=new_df.drop(columns = label)
#     # print(new_df)
#     # print(new_df.index.get_level_values(0).unique())
#     return new_df



if __name__ == '__main__':
    data_config = load_config("configs/data_config_day_factor.yaml")
    
    df = pd.read_pickle(data_config.factor_data_path)
    # df.index = pd.to_datetime(df.index.get_level_values('datetime'))
    # df=df.reset_index()
    # df['datetime'] = pd.to_datetime(df['datetime'])
    # df = df.rename(columns={'ts_code': 'instrument'})
    # df = df.rename(columns={'trade_date': 'datetime'})
    # df=df.set_index(['datetime','instrument'])

    # df.to_pickle(data_config.factor_data_path)

    df_data = df.dropna(axis=0, how='any')
    y_label = ['close']
    df_y = df_data[y_label]
    df_x = df_data.drop(columns = y_label)
    
    test_set = Day_Factor_new(data_frame_x=df_x, data_frame_y = df_y, fields=data_config.factors,
                            train_start=data_config.train_test_split.train_start, train_end=data_config.train_test_split.train_end,
                            valid_start=data_config.train_test_split.valid_start, valid_end=data_config.train_test_split.valid_end,
                            test_start=data_config.train_test_split.test_start, test_end=data_config.train_test_split.test_end,
                            mode = "test", T = data_config.T, H = data_config.label.H, label_type=data_config.label.type, label_weight = data_config.label.weight, 
                            pct=data_config.pct_mode)
    # print(test_set)
    X, Y, today, able_instrument = test_set[5]
    print(X.shape, Y.shape, today, able_instrument)
    from torch.utils.data import DataLoader
    loader = DataLoader(test_set, batch_size=1, shuffle=False, num_workers=16)
    # print(test_data[349])
    for (features, targets, today, able_instrument) in tqdm(loader):
        pass