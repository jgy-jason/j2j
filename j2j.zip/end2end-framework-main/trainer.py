import torch
import logging
from torch.nn.utils import clip_grad_norm_


class Trainer:
    def __init__(self,
                 model,
                 num_epoch,
                 train_loader,
                 valid_loaader,
                 test_loader,
                 optimizer,
                 shceduler,
                 custom_loss,
                 config,
                 early_stop_machine=None):
        
        self.model = model
        self.num_epoch = num_epoch
        self.train_loader = train_loader
        self.valid_loader = valid_loaader
        self.test_loader = test_loader
        self.optimizer = optimizer
        self.scheduler = shceduler
        self.custom_loss = custom_loss
        self.training_config = config
        self.early_stop_machine = early_stop_machine
        
    def train_one_loop(self, epoch):
        self.model.train()
        total_loss = 0
        for batch_idx, (data, target) in enumerate(self.train_loader):
        # for batch_idx, (data, target) in tqdm(enumerate(train_loader), total=len(train_loader)):
            if torch.cuda.is_available():
                if isinstance(data, list):
                    for i in range(len(data)):
                        data[i] = data[i].float().squeeze(0).cuda()
                else:
                    data = data.float().squeeze(0).cuda()
                target = target.float().squeeze(0).cuda()
            if 'adv' in self.training_config.ModelTraining.__dict__.keys():
                outputs, adv_outputs = self.model(data)
                self.optimizer.zero_grad()
                loss1 = self.custom_loss(outputs, target)
                loss2 = self.custom_loss(adv_outputs, target)
                loss = loss1 + self.training_config.ModelTraining.adv.lamb * loss2
                loss.backward()
            else:
                outputs = self.model(data)
                self.optimizer.zero_grad()
                loss = self.custom_loss(outputs, target)
                loss.backward()
                
            if self.training_config.TrainingArguments.clip_max_norm:
                clip_grad_norm_(self.model.parameters(), max_norm=self.training_config.TrainingArguments.clip_max_norm)

            self.optimizer.step()
            total_loss += loss.item()
            if batch_idx % self.training_config.TrainingArguments.log_steps == 0:
                logging.info('Train Epoch: {} [{}/{} ({:.0f}%)]\tLoss: {:.6f}'.format(
                    epoch, batch_idx, len(self.train_loader.dataset),
                    100. * batch_idx / len(self.train_loader), loss.item()))
        if self.scheduler:
            self.scheduler.step()
        return total_loss / len(self.train_loader)
    
    def evaluate_on_validation_dataset(self, validation_dataloader, use_adv=False):
        """
        Evaluate the model on the validation dataset to calculate mean IC and mean Rank IC.

        Parameters:
        model (torch.nn.Module): The model to evaluate.
        validation_dataloader (torch.utils.data.DataLoader): The DataLoader providing the validation dataset.

        Returns:
        Tuple[float, float]: The mean IC and mean Rank IC for the validation dataset.
        """
        self.model.eval()  # Set the model to evaluation mode.
        ic_scores = []
        rank_ic_scores = []
        total_loss = 0
        self_consistency = 0
        with torch.no_grad():  # No gradient computation during evaluation.
            for features, targets, _, _ in validation_dataloader:
            # for features, targets in tqdm(validation_dataloader, total = len(validation_dataloader)):
                if torch.cuda.is_available():
                    if isinstance(features, list):
                        for i in range(len(features)):
                            features[i] = features[i].float().squeeze(0).cuda()
                    else:
                        features = features.float().squeeze(0).cuda()
                    targets = targets.float().squeeze(0).cuda()
                if use_adv:
                    outputs, _ = self.model(features)
                else:
                    outputs = self.model(features)
                loss = self.custom_loss(outputs, targets)
                ic, rank_ic = self.evaluate_ic_rankic(outputs, targets)
                ic_scores.append(ic)
                rank_ic_scores.append(rank_ic)
                total_loss += loss.item()
                self_consistency += torch.mean(torch.corrcoef(outputs.T) ** 2)
        # Compute the mean scores across all validation data batches
        mean_ic = sum(ic_scores) / len(ic_scores)
        mean_rank_ic = sum(rank_ic_scores) / len(rank_ic_scores)
        
        return mean_ic, mean_rank_ic, total_loss / len(validation_dataloader), self_consistency / len(validation_dataloader)
    
    def evaluate_ic_rankic(self, outputs, target):
        """
        Evaluate the Information Coefficient (IC) and Rank Information Coefficient (Rank IC)
        between model outputs and actual labels.

        Parameters:
        outputs (Tensor): The model outputs, expected to be of shape (T, num_factors)
        target (Tensor): The actual labels, expected to be of shape (T,)

        Returns:
        Tuple[float, float]: A tuple containing the IC and Rank IC values.
        """
        # Ensure target is a float tensor
        target = target.float()

        # Ensure target is a 2D column vector
        target = target.view(-1, 1)
        # n * 64 
        # Calculate IC
        # Pearson correlation coefficient between the mean of the outputs and the target
        mean_outputs = torch.mean(outputs, dim=1)
        ic = torch.corrcoef(torch.stack((mean_outputs, target.squeeze())))[0, 1]

        # Calculate Rank IC
        # Spearman's rank correlation coefficient between the mean of the outputs and the target
        # This is done by ranking the data and then calculating Pearson's correlation
        rank_outputs = torch.argsort(torch.argsort(mean_outputs))
        rank_target = torch.argsort(torch.argsort(target.squeeze()))
        rank_ic = torch.corrcoef(torch.stack((rank_outputs.float(), rank_target.float())))[0, 1]

        return ic.item(), rank_ic.item()
    
    def train(self, args, Best_eval_IC, current_epoch=0):
        if 'adv' in self.training_config.ModelTraining.__dict__.keys():
            use_adv = True
        else:
            use_adv = False
            
            
        no_improvement = 0
        for epoch in range(current_epoch+1, self.training_config.epoch+1):  # 假设训练60个epoch
            train_loss = self.train_one_loop(epoch=epoch)
            logging.info(f"Training loss in epoch {epoch} is {train_loss}")
            # 可以添加验证步骤和保存模型的代码
            
            
            if self.early_stop_machine:
                self.early_stop_machine.update(self.model)
            
            if epoch % self.training_config.TrainingArguments.eval_freq == 0:
                mean_ic, mean_rank_ic, eval_loss, eval_corr = self.evaluate_on_validation_dataset(validation_dataloader=self.valid_loader, use_adv=use_adv)
                logging.info(f"Epoch {epoch} Valid Set: Mean IC: {mean_ic}, Mean Rank IC: {mean_rank_ic}, Eval loss {eval_loss}, Eval Corr {eval_corr}")
                
                mean_ic, mean_rank_ic, eval_loss, eval_corr = self.evaluate_on_validation_dataset(validation_dataloader=self.test_loader, use_adv=use_adv)
                logging.info(f"Epoch {epoch} Test Set:  Mean IC: {mean_ic}, Mean Rank IC: {mean_rank_ic}, Test loss {eval_loss}, Test Corr {eval_corr}")
                # if eval_loss < Best_eval_loss:
                #     Best_eval_loss = eval_loss
                #     torch.save({"state_dict":model.state_dict(), "epoch":epoch}, f'ckpt/{training_config.log_name}_best_loss_{training_config.ModelTraining.model_type}.bin')
                if self.early_stop_machine:
                    self.early_stop_machine(mean_rank_ic, self.model, epoch)
                    if self.early_stop_machine.early_stop:
                        logging.info("Early stopping!")
                        break
                else:
                    if mean_rank_ic > Best_eval_IC:
                        Best_eval_IC = mean_rank_ic
                        torch.save({"state_dict":self.model.state_dict(), "epoch":epoch, "best_ic":Best_eval_IC}, f'{args.output_dir}/{self.training_config.log_name}_best_ic_{self.training_config.ModelTraining.model_type}.bin')
                        logging.info("Updated Mean Rank IC Model!")
                        no_improvement = 0
                        
                    else:
                        no_improvement += 1
                        
                    if self.training_config.TrainingArguments.early_stop.patience > 0 and no_improvement > self.training_config.TrainingArguments.early_stop.patience:
                        logging.info("Early stopping!")
                        break

class Trainer_mult:
    def __init__(self,
                 model,
                 num_epoch,
                 train_loader1,
                train_loader2,
                train_loader3,
                valid_loaader1,
                valid_loaader2,
                valid_loaader3,
                 test_loader1,
                test_loader2,
                test_loader3,
                 optimizer,
                 shceduler,
                 custom_loss,
                 config,
                 early_stop_machine=None):
        
        self.model = model
        self.num_epoch = num_epoch
        self.train_loader1 = train_loader1
        self.valid_loader1 = valid_loaader1
        self.test_loader1 = test_loader1
        self.train_loader2 = train_loader2
        self.valid_loader2 = valid_loaader2
        self.test_loader2 = test_loader2
        self.train_loader3 = train_loader3
        self.valid_loader3 = valid_loaader3
        self.test_loader3 = test_loader3
        self.optimizer = optimizer
        self.scheduler = shceduler
        self.custom_loss = custom_loss
        self.training_config = config
        self.early_stop_machine = early_stop_machine
        
    def train_one_loop(self, epoch):
        self.model.train()
        total_loss = 0
        

        for batch_idx, (data, target) in enumerate(self.train_loader):
        # for batch_idx, (data, target) in tqdm(enumerate(train_loader), total=len(train_loader)):
            if torch.cuda.is_available():
                data, target = data.float().squeeze(0).cuda(), target.float().squeeze(0).cuda()
                
            if 'adv' in self.training_config.ModelTraining.__dict__.keys():
                outputs, adv_outputs = self.model(data)
                self.optimizer.zero_grad()
                loss1 = self.custom_loss(outputs, target)
                loss2 = self.custom_loss(adv_outputs, target)
                loss = loss1 + self.training_config.ModelTraining.adv.lamb * loss2
                loss.backward()
            else:
                outputs = self.model(data)
                self.optimizer.zero_grad()
                loss = self.custom_loss(outputs, target)
                loss.backward()
                
            if self.training_config.TrainingArguments.clip_max_norm:
                clip_grad_norm_(self.model.parameters(), max_norm=self.training_config.TrainingArguments.clip_max_norm)

            self.optimizer.step()
            total_loss += loss.item()
            if batch_idx % self.training_config.TrainingArguments.log_steps == 0:
                logging.info('Train Epoch: {} [{}/{} ({:.0f}%)]\tLoss: {:.6f}'.format(
                    epoch, batch_idx, len(self.train_loader.dataset),
                    100. * batch_idx / len(self.train_loader), loss.item()))
        if self.scheduler:
            self.scheduler.step()
        return total_loss / len(self.train_loader)
    
    def evaluate_on_validation_dataset(self, validation_dataloader, use_adv=False):
        """
        Evaluate the model on the validation dataset to calculate mean IC and mean Rank IC.

        Parameters:
        model (torch.nn.Module): The model to evaluate.
        validation_dataloader (torch.utils.data.DataLoader): The DataLoader providing the validation dataset.

        Returns:
        Tuple[float, float]: The mean IC and mean Rank IC for the validation dataset.
        """
        self.model.eval()  # Set the model to evaluation mode.
        ic_scores = []
        rank_ic_scores = []
        total_loss = 0
        self_consistency = 0
        with torch.no_grad():  # No gradient computation during evaluation.
            for features, targets, _, _ in validation_dataloader:
            # for features, targets in tqdm(validation_dataloader, total = len(validation_dataloader)):
                if torch.cuda.is_available():
                    features, targets = features.float().squeeze(0).cuda(), targets.float().squeeze(0).cuda()
                if use_adv:
                    outputs, _ = self.model(features)
                else:
                    outputs = self.model(features)
                loss = self.custom_loss(outputs, targets)
                ic, rank_ic = self.evaluate_ic_rankic(outputs, targets)
                ic_scores.append(ic)
                rank_ic_scores.append(rank_ic)
                total_loss += loss.item()
                self_consistency += torch.mean(torch.corrcoef(outputs.T) ** 2)
        # Compute the mean scores across all validation data batches
        mean_ic = sum(ic_scores) / len(ic_scores)
        mean_rank_ic = sum(rank_ic_scores) / len(rank_ic_scores)
        
        return mean_ic, mean_rank_ic, total_loss / len(validation_dataloader), self_consistency / len(validation_dataloader)
    
    def evaluate_ic_rankic(self, outputs, target):
        """
        Evaluate the Information Coefficient (IC) and Rank Information Coefficient (Rank IC)
        between model outputs and actual labels.

        Parameters:
        outputs (Tensor): The model outputs, expected to be of shape (T, num_factors)
        target (Tensor): The actual labels, expected to be of shape (T,)

        Returns:
        Tuple[float, float]: A tuple containing the IC and Rank IC values.
        """
        # Ensure target is a float tensor
        target = target.float()

        # Ensure target is a 2D column vector
        target = target.view(-1, 1)
        # n * 64 
        # Calculate IC
        # Pearson correlation coefficient between the mean of the outputs and the target
        mean_outputs = torch.mean(outputs, dim=1)
        ic = torch.corrcoef(torch.stack((mean_outputs, target.squeeze())))[0, 1]

        # Calculate Rank IC
        # Spearman's rank correlation coefficient between the mean of the outputs and the target
        # This is done by ranking the data and then calculating Pearson's correlation
        rank_outputs = torch.argsort(torch.argsort(mean_outputs))
        rank_target = torch.argsort(torch.argsort(target.squeeze()))
        rank_ic = torch.corrcoef(torch.stack((rank_outputs.float(), rank_target.float())))[0, 1]

        return ic.item(), rank_ic.item()
    
    def train(self, args, Best_eval_IC, current_epoch=0):
        if 'adv' in self.training_config.ModelTraining.__dict__.keys():
            use_adv = True
        else:
            use_adv = False
        
        for epoch in range(current_epoch+1, self.training_config.epoch+1):  # 假设训练60个epoch
            train_loss = self.train_one_loop(epoch=epoch)
            logging.info(f"Training loss in epoch {epoch} is {train_loss}")
            # 可以添加验证步骤和保存模型的代码
            
            
            if self.early_stop_machine:
                self.early_stop_machine.update(self.model)
            
            if epoch % self.training_config.TrainingArguments.eval_freq == 0:
                mean_ic, mean_rank_ic, eval_loss, eval_corr = self.evaluate_on_validation_dataset(validation_dataloader=self.valid_loader, use_adv=use_adv)
                logging.info(f"Epoch {epoch} Valid Set: Mean IC: {mean_ic}, Mean Rank IC: {mean_rank_ic}, Eval loss {eval_loss}, Eval Corr {eval_corr}")
                
                mean_ic, mean_rank_ic, eval_loss, eval_corr = self.evaluate_on_validation_dataset(validation_dataloader=self.test_loader, use_adv=use_adv)
                logging.info(f"Epoch {epoch} Test Set:  Mean IC: {mean_ic}, Mean Rank IC: {mean_rank_ic}, Test loss {eval_loss}, Test Corr {eval_corr}")
                # if eval_loss < Best_eval_loss:
                #     Best_eval_loss = eval_loss
                #     torch.save({"state_dict":model.state_dict(), "epoch":epoch}, f'ckpt/{training_config.log_name}_best_loss_{training_config.ModelTraining.model_type}.bin')
                if self.early_stop_machine:
                    self.early_stop_machine(mean_rank_ic, self.model, epoch)
                    if self.early_stop_machine.early_stop:
                        logging.info("Early stopping!")
                        break
                else:
                    if mean_rank_ic > Best_eval_IC:
                        Best_eval_IC = mean_rank_ic
                        torch.save({"state_dict":self.model.state_dict(), "epoch":epoch, "best_ic":Best_eval_IC}, f'{args.output_dir}/{self.training_config.log_name}_best_ic_{self.training_config.ModelTraining.model_type}.bin')
                        logging.info("Updated Mean Rank IC Model!")
                        no_improvement = 0
                        
                    else:
                        no_improvement += 1
                        
                    if self.training_config.TrainingArguments.early_stop.patience > 0 and no_improvement > self.training_config.TrainingArguments.early_stop.patience:
                        logging.info("Early stopping!")
                        break

# def train_loop(epoch, model, train_loader, optimizer, scheduler, custom_loss, config):
#     model.train()
#     total_loss = 0
#     for batch_idx, (data, target) in enumerate(train_loader):
#     # for batch_idx, (data, target) in tqdm(enumerate(train_loader), total=len(train_loader)):
#         if torch.cuda.is_available():
#             data, target = data.float().squeeze(0).cuda(), target.float().squeeze(0).cuda()
            
#         if 'adv' in config.ModelTraining.__dict__.keys():
#             outputs, adv_outputs = model(data)
#             optimizer.zero_grad()
#             loss1 = custom_loss(outputs, target)
#             loss2 = custom_loss(adv_outputs, target)
#             loss = loss1 + config.ModelTraining.adv.lamb * loss2
#             loss.backward()
#         else:
#             outputs = model(data)
#             optimizer.zero_grad()
#             loss = custom_loss(outputs, target)
#             loss.backward()
            
#         if config.TrainingArguments.clip_max_norm:
#             clip_grad_norm_(model.parameters(), max_norm=config.TrainingArguments.clip_max_norm)

#         optimizer.step()
#         total_loss += loss.item()
#         if batch_idx % config.TrainingArguments.log_steps == 0:
#             logging.info('Train Epoch: {} [{}/{} ({:.0f}%)]\tLoss: {:.6f}'.format(
#                 epoch, batch_idx, len(train_loader.dataset),
#                 100. * batch_idx / len(train_loader), loss.item()))
#     if scheduler:
#         scheduler.step()
#     return total_loss / len(train_loader)

# def evaluate_on_validation_dataset(model, custom_loss, validation_dataloader, use_adv = False):
#     """
#     Evaluate the model on the validation dataset to calculate mean IC and mean Rank IC.

#     Parameters:
#     model (torch.nn.Module): The model to evaluate.
#     validation_dataloader (torch.utils.data.DataLoader): The DataLoader providing the validation dataset.

#     Returns:
#     Tuple[float, float]: The mean IC and mean Rank IC for the validation dataset.
#     """
#     model.eval()  # Set the model to evaluation mode.
#     ic_scores = []
#     rank_ic_scores = []
#     total_loss = 0
#     self_consistency = 0
#     with torch.no_grad():  # No gradient computation during evaluation.
#         for features, targets, _, _ in validation_dataloader:
#         # for features, targets in tqdm(validation_dataloader, total = len(validation_dataloader)):
#             if torch.cuda.is_available():
#                 features, targets = features.float().squeeze(0).cuda(), targets.float().squeeze(0).cuda()
#             if use_adv:
#                 outputs, _ = model(features)
#             else:
#                 outputs = model(features)
#             loss = custom_loss(outputs, targets)
#             ic, rank_ic = evaluate_ic_rankic(outputs, targets)
#             ic_scores.append(ic)
#             rank_ic_scores.append(rank_ic)
#             total_loss += loss.item()
#             self_consistency += torch.mean(torch.corrcoef(outputs.T) ** 2)
#     # Compute the mean scores across all validation data batches
#     mean_ic = sum(ic_scores) / len(ic_scores)
#     mean_rank_ic = sum(rank_ic_scores) / len(rank_ic_scores)
    
#     return mean_ic, mean_rank_ic, total_loss / len(validation_dataloader), self_consistency / len(validation_dataloader)

# def evaluate_ic_rankic(outputs, target):
#     """
#     Evaluate the Information Coefficient (IC) and Rank Information Coefficient (Rank IC)
#     between model outputs and actual labels.

#     Parameters:
#     outputs (Tensor): The model outputs, expected to be of shape (T, num_factors)
#     target (Tensor): The actual labels, expected to be of shape (T,)

#     Returns:
#     Tuple[float, float]: A tuple containing the IC and Rank IC values.
#     """
#     # Ensure target is a float tensor
#     target = target.float()

#     # Ensure target is a 2D column vector
#     target = target.view(-1, 1)
#     # n * 64 
#     # Calculate IC
#     # Pearson correlation coefficient between the mean of the outputs and the target
#     mean_outputs = torch.mean(outputs, dim=1)
#     ic = torch.corrcoef(torch.stack((mean_outputs, target.squeeze())))[0, 1]

#     # Calculate Rank IC
#     # Spearman's rank correlation coefficient between the mean of the outputs and the target
#     # This is done by ranking the data and then calculating Pearson's correlation
#     rank_outputs = torch.argsort(torch.argsort(mean_outputs))
#     rank_target = torch.argsort(torch.argsort(target.squeeze()))
#     rank_ic = torch.corrcoef(torch.stack((rank_outputs.float(), rank_target.float())))[0, 1]

#     return ic.item(), rank_ic.item()