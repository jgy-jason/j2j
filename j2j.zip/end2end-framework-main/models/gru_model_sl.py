#%%
import torch
import torch.nn as nn
import torch.nn.functional as F

class GRUBNFCNet_sl(nn.Module):
    def __init__(self, input_features=7, gru_hidden_size=128, num_layers = 1,fc_out_features=64):
        super(GRUBNFCNet_sl, self).__init__()
        self.gru = nn.GRU(input_size=input_features, hidden_size=gru_hidden_size, num_layers=num_layers,batch_first=True)
        self.bn = nn.BatchNorm1d(num_features=fc_out_features)
        self.fc = nn.Linear(gru_hidden_size, fc_out_features)
        
    def forward(self, x):
        x = x.permute(0, 2, 1)
        x, h = self.gru(x)  # x is of shape (B, seq_length, gru_hidden_size)
        x = self.fc(x[:,-1,:])  # Apply BN
        x = self.bn(x)  # Apply FC to the last output and then apply sigmoid
        return x

# 定义模型

#%%
    
if __name__ == '__main__':
    model = GRUBNFCNet_sl(7, 128, 64)
    X = torch.randn((5, 7, 63))
    Y = model(X)
    print(Y.shape)
# %%
