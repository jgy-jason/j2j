#%%
import torch
import torch.nn as nn
import torch.nn.functional as F
import math
from typing import Dict, List
#%%
def get_lcm(a: int, b: int) -> int:
    return int(round(a * b / math.gcd(a, b)))

class SelfAttention(nn.Module):
    def __init__(self, num_scales):
        super(SelfAttention, self).__init__()
        
        self.query = nn.Linear(num_scales, num_scales)
        self.key = nn.Linear(num_scales, num_scales)
        self.softmax = nn.Softmax(dim=2)

    def forward(self, lstm_outputs):
        # Extract the last hidden states of all LSTMs
        lstm_last_hidden_states = torch.stack([output[:, -1, :] for output in lstm_outputs], dim=2) # [batch_size, hidden_size, num_scales]

        # Average the hidden states to get a single vector representation for each LSTM
      #  lstm_representations = lstm_last_hidden_states.mean(dim=1) # [batch_size, num_scales]

        # Compute the Q and K matrices
        Q = self.query(lstm_last_hidden_states) # [batch_size, hidden_size, num_scales]
        K = self.key(lstm_last_hidden_states)   # [batch_size, hidden_size, num_scales]

        #  # Calculate attention scores
        attention_scores = torch.bmm(Q, K.transpose(1, 2))  # [batch_size, num_scales, num_scales]
        attention_weights = self.softmax(attention_scores)  # [batch_size, num_scales, num_scales]

        # Compute weighted output using the attention weights
        weighted_outputs = torch.bmm(attention_weights, lstm_last_hidden_states)  # [batch_size, num_scales, hidden_size]
        
        # Sum along the 'num_scales' dimension to get the final representation
        final_representation = weighted_outputs.sum(dim=2).squeeze(-1)  # [batch_size, hidden_size]

        return final_representation


class MultiScaleRNN(nn.Module):
    def __init__(
        self,
        input_size: int,
        seq_len: int,
        hidden_size: int,
        num_layers: int,
        dropout: float,
        scales: List[int],
    ):
        super(MultiScaleRNN, self).__init__()
        self.scales = scales
        self.input_size = input_size
        self.seq_len = seq_len
        self._init_multi_scale_rnn(num_layers, hidden_size, dropout)
        self.att = SelfAttention(len(scales))

    def _init_multi_scale_rnn(
        self,
        num_layers: int,
        hidden_size: int,
        dropout: float,
    ) -> None:
        if len(self.scales) == 1:
            lcm = self.scales[0]
        else:
            lcm = get_lcm(*self.scales[:2])
            print(lcm)
            for scale in self.scales[2:]:
                lcm = get_lcm(lcm, scale)
        if self.seq_len % lcm != 0:
            raise ValueError(f"time steps should be divisible by {lcm}")
        self.multi_scale_rnns = nn.ModuleList(
            [
                nn.LSTM(
                    input_size=self.input_size*2,
                    hidden_size=hidden_size,
                    num_layers=num_layers,
                    dropout=dropout,
                    batch_first=True,
                )
                for _ in self.scales
            ]
        )
        # self.dimension_reducer = nn.Sequential(
        #     nn.Linear(len(self.scales), 1),  # 假设你有len(scales)个LSTM
        #    # nn.ELU(),
        # )
        self.mlp = nn.Sequential(
            
            nn.Linear(hidden_size, 64),
            nn.BatchNorm1d(64),
            # nn.LeakyReLU(),
            # nn.Linear(64, 1),
         #   nn.BatchNorm1d(64),
        )
        self.conv1x1 = nn.Conv1d(self.input_size, self.input_size, kernel_size=1)
 
        # self.cnn1d = nn.Sequential(
        # self.multi_scale_rnns_backward = nn.ModuleList(
        #     [
        #         nn.GRU(
        #             input_size=self.input_size,
        #             hidden_size=hidden_size,
        #             num_layers=num_layers,
        #             dropout=dropout,
        #             batch_first=True,
        #         )
        #         for _ in self.scales
        #     ]
        # )
        # nn.leaky_relu_ = nn.LeakyReLU(0.1)
    def _extract(self, net: torch.Tensor, gap: int) -> torch.Tensor:
        indices = torch.tensor(list(range(0, self.seq_len, gap)) + [-1])
        return net[:, indices]


    def _get_nets_reverse(self, net: torch.Tensor) -> List[torch.Tensor]:
        nets = []
        for i, scale in enumerate(sorted(self.scales, reverse=True)):
            nets.append(self.multi_scale_rnns_backward[i](self._extract(net, scale))[0])
        return nets
    # def _get_nets_reverse(self, net: torch.Tensor, lstm_outputs: List[torch.Tensor]) -> List[torch.Tensor]:
    #     """残差法"""
    #     nets = []
    #     for i, scale in enumerate(sorted(self.scales, reverse=True)):
    #         residual = self._extract(net, scale) - lstm_outputs[i]
    #         nets.append(self.multi_scale_rnns_backward[i](residual)[0])
    #     return nets.flip(dims=[1])
    

    def _get_nets(self, net: torch.Tensor) -> List[torch.Tensor]:
        nets = []
        for i, scale in enumerate(sorted(self.scales, reverse=True)):
            nets.append(self.multi_scale_rnns[i](self._extract(net, scale))[0])
        return nets

    def forward(
        self,x
    ) -> Dict[str, torch.Tensor]:
        #x = batch["x"]
        x = x.permute(0, 2, 1)
        x = x.squeeze()
        # nets = self._get_nets(x)
        conv_output = self.conv1x1(x.transpose(1, 2)).transpose(1, 2)
        
        # 将原始数据和卷积后的数据连接起来
        concatenated_input = torch.cat([x, conv_output], dim=2) # 在特征维度上连接
        
        nets = self._get_nets(concatenated_input)
      
        emb = self.att(nets).squeeze(-1)
        # # # 使用降维网络
        # emb = self.dimension_reducer(concatenated_hidden_states).squeeze(-1)

        out = self.mlp(emb)
        

        return out
#%%
if __name__ == '__main__':
    model = MultiScaleRNN(7, 30, 64,2,0.1,[1,5,10,15])
    X = torch.ones((5000, 7, 30))
    Y = model(X)
    print(Y.shape)
# %%
