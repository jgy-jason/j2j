import torch
import torch.nn as nn
import torch.nn.functional as F


class LSTMModel(nn.Module):
    def __init__(self, input_size=7, hidden_size=64, output_size=128,num_layers=2, dropout=0.1):
        super().__init__()

        self.rnn = nn.LSTM(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout,
        )
        self.fc_out = nn.Linear(hidden_size, output_size)
        self.BN = nn.BatchNorm1d(output_size)
        self.input_size = input_size

    def forward(self, x):
        # x: [N, F*T]
        x = x.permute(0, 2, 1)  # [N, T, F]
        out, _ = self.rnn(x)
        fcout  = self.fc_out(out[:, -1, :])
        bnout = self.BN(fcout)
        return bnout
    
if __name__ == '__main__':
    model = LSTMModel(7,)
    X = torch.ones((5000, 7, 63))
    Y = model(X)
    print(Y.shape)