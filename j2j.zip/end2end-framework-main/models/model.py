import torch
import torch.nn as nn
import torch.nn.functional as F
# from rev_grad import RevGrad
# from gru_model import GRUBNFCNet

class Alpha_Factor_Model(nn.Module):
    def __init__(self, base_model, rev_grad=None):
        super(Alpha_Factor_Model, self).__init__()
        self.base_model = base_model
        self.rev_grad = rev_grad
        
    def forward(self, x):
        x = self.base_model(x)
        if self.rev_grad:
            adv_x = self.rev_grad(x)
            return x, adv_x
        return x
    

if __name__ == '__main__':
    base = GRUBNFCNet(7, 128, 64)
    rev = RevGrad(0.1, 0.4)
    
    model = Alpha_Factor_Model(base, rev)
    X = torch.ones((5000, 7, 63))
    y, adv = model(X)
    print(y.shape, adv.shape)