import torch
import torch.nn as nn
import torch.nn.functional as F

class Attention(nn.Module):
    def __init__(self, gru_hidden_size):
        super(Attention, self).__init__()
        self.attention_fc = nn.Linear(2 * gru_hidden_size, 1)

    def forward(self, x):
        # x 的形状: [B, seq_length, 2 * gru_hidden_size] (因为是双向)
        attention_weights = self.attention_fc(x).squeeze(2)
        attention_weights = F.softmax(attention_weights, dim=1)
        
        # 应用注意力权重
        attention_weights = attention_weights.unsqueeze(2)
        weighted_gru_output = x * attention_weights

        # 求和加权输出
        weighted_sum = torch.sum(weighted_gru_output, dim=1)
        return weighted_sum

class BiAGRU(nn.Module):
    def __init__(self, input_features=418, gru_hidden_size=128, num_layers=1, fc_out_features=64, use_sigmoid=True):
        super(BiAGRU, self).__init__()
        self.gru = nn.GRU(input_size=input_features, hidden_size=gru_hidden_size, num_layers=num_layers, batch_first=True, bidirectional=True)
        self.attention = Attention(gru_hidden_size)
        self.bn = nn.BatchNorm1d(2 * gru_hidden_size)  # 注意特征维度加倍
        self.fc = nn.Linear(2 * gru_hidden_size, fc_out_features)  # 输入特征维度加倍
        self.use_sigmoid = use_sigmoid
        
    def forward(self, x):
        x = x.permute(0, 2, 1)
        # print(x.shape)
        x, _ = self.gru(x)  # x is of shape (B, seq_length, 2 * gru_hidden_size)

        # 应用注意力机制
        x = self.attention(x)  # x is now of shape (B, 2 * gru_hidden_size)

        # 应用批量归一化
        x = self.bn(x)

        # 应用全连接层和可选的 Sigmoid 激活函数
        if self.use_sigmoid:
            x = torch.sigmoid(self.fc(x))
        else:
            x = self.fc(x)
        # print(x.shape)
        return x

class MLP(nn.Module):
    def __init__(self, input_size, output_size):
        super(MLP, self).__init__()
        self.fc = nn.Linear(input_size, output_size)
    
    def forward(self, x):
        return self.fc(x)

class GRUBarra(nn.Module):
    def __init__(self, input_features,
                 gru_hidden_size, 
                 num_layers, 
                 fc_out_features, 
                 use_sigmoid, 
                 barra_input_size, 
                 barra_output_size,
                 hidden_input_size, 
                 hidden_output_size,
                 final_output_size):
        super(GRUBarra, self).__init__()
        self.base_model = self.base_model = BiAGRU(input_features, gru_hidden_size, num_layers, fc_out_features, use_sigmoid)
        self.barra = nn.Linear(barra_input_size, barra_output_size)
        self.hidden = nn.Linear(hidden_input_size, hidden_output_size)
        self.mlp = MLP(hidden_output_size, final_output_size)

    def forward(self, inputs):  # 修改参数名
        x_barra,x2= inputs
        x2 = self.base_model(x2)  # 将 x 替换为 x2
        x1 = self.barra(x_barra)  # 将 x2 替换为 x1
        # print(x1.shape)
        x = torch.cat((x2, x1), dim=1)
        x_64 = self.hidden(x)
        x = self.mlp(x_64)
        return x, [x,x_barra]

if __name__ == '__main__':
    input_features = 418
    gru_hidden_size = 128
    num_layers = 1
    fc_out_features = 64
    barra_input_size = 11
    barra_output_size = 11
    hidden_input_size = 75
    hidden_output_size=64
    final_output_size = 1
    use_sigmoid = True

    model = GRUBarra(input_features, gru_hidden_size, num_layers, fc_out_features, use_sigmoid, barra_input_size, barra_output_size,hidden_input_size, 
                 hidden_output_size,final_output_size)

    x2 = torch.ones((500, 418, 63))  # 修改变量名
    x1 = torch.ones((500, 11))  # 修改变量名
    y= model(x2, x1)
    print(y.shape)
