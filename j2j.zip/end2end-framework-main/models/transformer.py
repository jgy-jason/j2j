
import torch
import torch.nn as nn
import torch.nn.functional as F
import math 
from torchkeras import summary

class PositionalEncoding(nn.Module):
    def __init__(self, d_model, max_len=1000):
        super(PositionalEncoding, self).__init__()
        pe = torch.zeros(max_len, d_model)
        #print(pe)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        #print(position)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        #print(div_term)
        pe[:, 0::2] = torch.sin(position * div_term)
        #print(pe[:, 0::2])
        pe[:, 1::2] = torch.cos(position * div_term)
        #print(pe[:, 1::2])
        pe = pe.unsqueeze(0).transpose(0, 1)
        #print(pe)
        self.register_buffer("pe", pe)

    def forward(self, x):
        # [T, N, F]
        return x + self.pe[: x.size(0), :]


class Transformer(nn.Module):
    def __init__(self, input_size=8, d_model=8, nhead=4, num_layers=2, output_size=64,dropout=0.5):
        super(Transformer, self).__init__()
        self.feature_layer = nn.Linear(input_size, d_model)
        print(self.feature_layer)
        self.pos_encoder = PositionalEncoding(d_model)
        self.encoder_layer = nn.TransformerEncoderLayer(d_model=d_model, nhead=nhead, dropout=dropout)
        self.transformer_encoder = nn.TransformerEncoder(self.encoder_layer, num_layers=num_layers)
        self.decoder_layer = nn.Linear(d_model, output_size)
        self.input_size = input_size

    def forward(self, src):

        src = src.permute(0, 2, 1)
        src = self.feature_layer(src)
        

        # src [N, T, F] --> [T, N, F], [60, 512, 8]
        src = src.transpose(1, 0)  # not batch first

        mask = None

        src = self.pos_encoder(src)
        output = self.transformer_encoder(src, mask)  # [60, 512, 8]

        # [T, N, F] --> [N, T*F]
        output = self.decoder_layer(output.transpose(1, 0)[:, -1, :])  # [512, 1]

        return output.squeeze()
#%%
if __name__ == '__main__':
    model = Transformer(7,8,4,2,64,0.5)
    summary(model,input_shape=(7,63))
    X = torch.ones((5000, 7, 63))
    Y = model(X)
    print(Y.shape)
