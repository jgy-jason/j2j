from lightgbm import LGBMClassifier
import lightgbm as lgb

class LightGBMModel:
    def __init__(self, num_leaves=31, max_depth=-1, learning_rate=0.1):
        # 初始化 LightGBM 分类器
        self.model = LGBMClassifier(
            num_leaves=num_leaves,
            max_depth=max_depth,
            learning_rate=learning_rate
        )
    def train(self, train_data, train_labels, valid_data=None, valid_labels=None, num_rounds=100):
        # 训练模型
        self.model.fit(
            train_data,
            train_labels,
            eval_set=[(valid_data, valid_labels)] if valid_data is not None else None,
            early_stopping_rounds=10,
            verbose_eval=True,
            num_boost_round=num_rounds
        )
    
    def predict(self, data):
        # 使用模型进行预测
        return self.model.predict(data)

# 使用模型
if __name__ == '__main__':
    model = LightGBMModel(num_leaves=31, max_depth=9, learning_rate=0.05)
    
    # 训练模型
    model.train(train_data=X_train, train_labels=y_train, valid_data=X_valid, valid_labels=y_valid, num_rounds=200)
    
    # 进行预测
    predictions = model.predict(X_valid)
    
    # 打印预测结果的形状
    print(predictions.shape)

if __name__ == "__main__":
    past_series = torch.rand(5000, 63)
    model = HISTModel(7, 64, 4, 128, 2, 64, 63)
    pred_series = model(past_series)
    print(pred_series.shape)