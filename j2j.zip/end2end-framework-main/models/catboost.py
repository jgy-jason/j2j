from catboost import CatBoostClassifier, Pool
import numpy as np

class CatBoostModel:
    def __init__(self, learning_rate=0.1, depth=6, iterations=100):
        # 初始化 CatBoost 分类器
        self.model = CatBoostClassifier(
            learning_rate=learning_rate,
            depth=depth,
            iterations=iterations
        )
    
    def train(self, X_train, y_train, X_valid=None, y_valid=None):
        # 准备数据集
        train_data = Pool(data=X_train, label=y_train)
        valid_data = Pool(data=X_valid, label=y_valid) if X_valid is not None and y_valid is not None else None
        
        # 训练模型
        self.model.fit(train_data, eval_set=valid_data, verbose=False)
    
    def predict(self, X):
        # 使用模型进行预测
        return self.model.predict(X)

# 使用模型
if __name__ == '__main__':
    # 假设 X_train, y_train, X_valid, y_valid 是已经准备好的训练和验证数据集
    # X_train = ...
    # y_train = ...
    # X_valid = ...
    # y_valid = ...
    
    # 创建 CatBoost 模型实例
    model = CatBoostModel(learning_rate=0.1, depth=6, iterations=100)
    
    # 训练模型
    model.train(X_train, y_train, X_valid, y_valid)
    
    # 进行预测
    predictions = model.predict(X_valid)
    
    # 打印预测结果的形状
    print(predictions.shape)