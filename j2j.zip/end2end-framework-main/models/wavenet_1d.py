import torch
import torch.nn as nn
import torch.nn.functional as F

class DilatedCausalConv1D(nn.Module):
    """一个扩张因果卷积层"""
    def __init__(self, in_channels, out_channels, dilation_rate):
        super(DilatedCausalConv1D, self).__init__()
        self.conv = nn.Conv1d(in_channels, out_channels, kernel_size=2, padding=dilation_rate, dilation=dilation_rate)

    def forward(self, x):
        x = self.conv(x)
        # 裁剪最后几个元素，以保持因果关系
        return x[:, :, :-self.conv.padding[0]]

class WaveNetBlock(nn.Module):
    """WaveNet中的一个块，包含扩张因果卷积和跳跃连接"""
    def __init__(self, residual_channels, skip_channels, dilation_rate):
        super(WaveNetBlock, self).__init__()
        self.dilated_conv = DilatedCausalConv1D(residual_channels, residual_channels, dilation_rate)
        self.skip_conv = nn.Conv1d(residual_channels, skip_channels, kernel_size=1)
        self.residual_conv = nn.Conv1d(residual_channels, residual_channels, kernel_size=1)

    def forward(self, x):
        res = x
        x = F.relu(self.dilated_conv(x))
        skip = self.skip_conv(x)
        res = self.residual_conv(x) + res
        return res, skip

class WaveNetModel(nn.Module):
    """简化版的1D WaveNet模型，输出形状为[B, 64]"""
    def __init__(self, in_channels, residual_channels, skip_channels, num_blocks, num_layers, output_features=64):
        super(WaveNetModel, self).__init__()
        self.initial_conv = nn.Conv1d(in_channels, residual_channels, kernel_size=1)
        self.blocks = nn.ModuleList()
        for _ in range(num_blocks):
            for i in range(num_layers):
                dilation_rate = 2 ** i
                self.blocks.append(WaveNetBlock(residual_channels, skip_channels, dilation_rate))
        self.final_conv_layers = nn.Sequential(
            nn.ReLU(),
            nn.Conv1d(skip_channels, skip_channels, kernel_size=1),
            nn.ReLU(),
            nn.Conv1d(skip_channels, output_features, kernel_size=1)
        )
        # 将所有序列的信息汇总到一个单独的向量
        self.global_pooling = nn.AdaptiveAvgPool1d(1)

    def forward(self, x):
        x = self.initial_conv(x)
        skip_connections = []
        for block in self.blocks:
            x, skip = block(x)
            skip_connections.append(skip)
        x = sum(skip_connections)
        x = self.final_conv_layers(x)
        # 应用全局池化以将形状变为[B, output_features, 1]
        x = self.global_pooling(x).squeeze(-1)  # 移除最后一个维度
        return x

    
if __name__ == '__main__':
    TCN = WaveNetModel(7, 32, 64, 2, 4)
    X = torch.ones((5000, 7, 63))
    Y = TCN(X)
    print(Y.shape)