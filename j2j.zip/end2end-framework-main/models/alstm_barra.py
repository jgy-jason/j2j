#%%
import torch
import torch.nn as nn
import torch.nn.functional as F

class alstm(nn.module):
    def __init__(base_model, barra):
        self.base_model = base_model
        self.barra = barra
        self.mlp = MLP()

    def forward(self, x, t):
        x = self.base_model(x)
        br = self.barra(t)
        x = torch.cat(x, br)
        x = self.mlp(x)
        return x
    