import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
# from torchmetrics.regression import R2Score

# from .dlmodel import DLModel

class RNNModule(nn.Module):
    """
    GRU module
    input:  (Batch,Timestep,Features)
    output: (Batch,Timestep,Features)
    """

    def __init__(self, input_dim, hidden_dim, num_layers=1):
        super(RNNModule, self).__init__()
        self.id = input_dim
        self.rnn = nn.GRU(
            input_size=input_dim,
            hidden_size=hidden_dim,
            num_layers=num_layers,
            batch_first=True,
        )

    def forward(self, x):
        out, _ = self.rnn(x)
        return out
    
class ADJModule(nn.Module):
    def __init__(self, nnodes=5000, k=200, dim=19, alpha=3, static_feat='static_feat'):
        super(ADJModule, self).__init__()
        self.nnodes = nnodes
        if static_feat is not None:
            self.lin1 = nn.Linear(dim, dim)
            self.lin2 = nn.Linear(dim, dim)
        else:
            self.emb1 = nn.Embedding(nnodes, dim)
            self.emb2 = nn.Embedding(nnodes, dim)
            self.lin1 = nn.Linear(dim,dim)
            self.lin2 = nn.Linear(dim,dim)

        self.k = k
        self.dim = dim
        self.alpha = alpha
        self.static_feat = static_feat

    def forward(self, x):
        idx = torch.arange(self.nnodes)
        if self.static_feat is None:
            nodevec1 = self.emb1(idx)
            nodevec2 = self.emb2(idx)
        else:
            nodevec1 = x[:,-1,9:]
            nodevec2 = nodevec1

        nodevec1 = torch.tanh(self.alpha*self.lin1(nodevec1))
        nodevec2 = torch.tanh(self.alpha*self.lin2(nodevec2))

        a = torch.mm(nodevec1, nodevec2.transpose(1,0))-torch.mm(nodevec2, nodevec1.transpose(1,0))
        adj = F.relu(torch.tanh(self.alpha*a))
        mask = torch.zeros(idx.size(0), idx.size(0))
        mask.fill_(float('0'))
        s1,t1 = (adj + torch.rand_like(adj)*0.01).topk(self.k,1)
        mask.scatter_(1,t1,s1.fill_(1))
        adj = adj*mask
        return adj

    def fullA(self, x):
        idx = torch.arange(self.nnodes) 
        if self.static_feat is None:
            # idx = torch.arange(self.nnodes).to(x.device)
            nodevec1 = self.emb1(idx)
            nodevec2 = self.emb2(idx)
        else:
            nodevec1 = x[:,-1,:5]
            nodevec2 = nodevec1

        nodevec1 = torch.tanh(self.alpha*self.lin1(nodevec1))
        nodevec2 = torch.tanh(self.alpha*self.lin2(nodevec2))

        a = torch.mm(nodevec1, nodevec2.transpose(1,0))-torch.mm(nodevec2, nodevec1.transpose(1,0))
        adj = F.relu(torch.tanh(self.alpha*a))
        return adj
    
    def compute_adj_matrix(self, x):
        adj_input = x[:, -1, 5]
        # adj_input = x[:, 4]
        n_stocks = adj_input.shape[0]
        adj_matrix = torch.zeros((n_stocks, n_stocks), dtype=torch.int)
        for i in range(n_stocks):
            for j in range(i+1, n_stocks):  # 只需要比较上三角矩阵，避免重复比较
                if adj_input[i] == adj_input[j]:
                    adj_matrix[i, j] = 1
                    adj_matrix[j, i] = 1 
        adj_matrix.fill_diagonal_(0)
        return adj_matrix


class AttentionModule(nn.Module):
    """
    Attention module
    input:  (Batch,Timestep,Features)
    output: (Batch,Timestep=-1,Features)
    """
    def __init__(self, hidden_dim):
        super(AttentionModule, self).__init__()
        self.hidden_dim = hidden_dim
        self.attention = nn.MultiheadAttention(hidden_dim, num_heads=1, batch_first=True)
    
    def forward(self, hidden):
        att_output, _ = self.attention(hidden, hidden, hidden)

        return att_output[:, -1, :]
    

class GATModule(nn.Module):
    """
    GAT module
    input: (N, N) adjacency matrix
    output: (N, K-factors)
    """

    def __init__(self, in_features, out_features, alpha=0.2):
        super(GATModule, self).__init__()
        self.in_features = in_features
        self.out_features = out_features

        self.W = nn.Parameter(torch.zeros(size=(in_features, out_features)))
        self.a = nn.Parameter(torch.zeros(size=(2 * out_features, 1)))
        nn.init.xavier_uniform_(self.W.data)  # initialize weight
        nn.init.xavier_uniform_(self.a.data)  # initialize attention weight
        self.leakyRelu = nn.LeakyReLU(alpha)

    def get_attention_input(self, Wh):
        n = Wh.size()[0]  # num nodes
        Wh_repeated_in_chunks = Wh.repeat_interleave(n, dim=0)  # repeat each node's feature vector N times
        Wh_repeated_alternating = Wh.repeat(n, 1)  # repeat the entire feature matrix N times
        mat = torch.cat([Wh_repeated_in_chunks, Wh_repeated_alternating], dim=1)# concat repeated features
        return mat.view(n, n, 2 * self.out_features)  # reshape

    def forward(self, h, adj):
        # print((self.W).shape)
        Wh = torch.mm(h, self.W)
        a_input = self.get_attention_input(Wh)
        e = self.leakyRelu(torch.matmul(a_input, self.a).squeeze(2))  # attention score

        zero_vec = -9e15 * torch.ones_like(e)
        attn  = torch.where(adj > 0, e, zero_vec)  # mask attention score
        attn  = F.softmax(attn , dim=1)
        attn  = F.dropout(attn , 0.6, training=self.training)
        h_p = torch.matmul(attn , Wh)  # node feature of neighbors

        return F.elu(h_p)

class GRUAttGAT(nn.Module):
    """
    GNN+GAT structure
    input: (Time, N)
    output: (N, K-factors)
    """
    def __init__(self, input_size=19, rnn_hidden_size=128, gat_out_feat=19):
        """
        input_size: 每个 time step 的 feature 数量
        """
        super(GRUAttGAT, self).__init__()
        self.GRU = RNNModule(input_size, rnn_hidden_size)
        self.adj=ADJModule(nnodes=500, k=200, dim=10, alpha=3, static_feat="stock_features")
        self.Attention = AttentionModule(rnn_hidden_size)
        self.GAT = GATModule(2*rnn_hidden_size, gat_out_feat)
        self.fc = nn.Sequential(
            nn.Linear(2*gat_out_feat, 2*gat_out_feat),
            nn.BatchNorm1d(2*gat_out_feat),
            nn.ReLU(),
            nn.Linear(2*gat_out_feat, input_size)
        )

    def forward(self, x_rnn):
        GRU_out = self.GRU(x_rnn)
        att_out = self.Attention(GRU_out)
        adj_matr1 = self.adj(x_rnn)
        adj_matr2 = self.adj.compute_adj_matrix(x_rnn)
        gat_out1 = self.GAT(torch.cat([att_out, GRU_out[:,-1,:]], dim=1), adj_matr1)
        gat_out2 = self.GAT(torch.cat([att_out, GRU_out[:,-1,:]], dim=1), adj_matr2)
        return self.fc(torch.cat([gat_out1,gat_out2], dim=1))

# class RM(DLModel):
#     def __init__(self, model=GRUGAT(), lambda_=0.7, n_epochs=200, loss="r2s"):
#         super().__init__(model=model)
#         self.lambda_ = lambda_

#     def r2loss(self, output, target, weight):
#         r2s = R2Score()
#         r_sq = torch.norm(weight * r2s(output, target))
#         reg = self.lambda_ * torch.norm(torch.corrcoef(output)) ** 2  # 相邻系数矩阵
#         loss = r_sq + reg
#         return loss

#     def loss_fn(self, pred, label, weight=None):
#         mask = ~torch.isnan(label)
#         if weight is None:
#             weight = torch.ones_like(label)
#         pred, z = (
#             pred[:,-1],
#             pred[:, :-1],
#         )
        
#         return loss

if __name__ == '__main__':
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = GRUAttGAT(19, 128, 19)
    X = torch.ones((500, 63, 19))
    Y = model(X)
    print(Y.shape)