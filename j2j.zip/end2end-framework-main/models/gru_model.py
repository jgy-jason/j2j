import torch
import torch.nn as nn
import torch.nn.functional as F

class GRUBNFCNet(nn.Module):
    def __init__(self, input_features=7, gru_hidden_size=128, num_layers = 1,fc_out_features=64, use_sigmoid=True):
        super(GRUBNFCNet, self).__init__()
        self.gru = nn.GRU(input_size=input_features, hidden_size=gru_hidden_size, num_layers=num_layers,batch_first=True)
        self.bn = nn.BatchNorm1d(num_features=gru_hidden_size)
        self.fc = nn.Linear(gru_hidden_size, fc_out_features)
        self.use_sigmoid = use_sigmoid
        
    def forward(self, x):
        x = x.permute(0, 2, 1)
        x, h = self.gru(x)  # x is of shape (B, seq_length, gru_hidden_size)
        x = self.bn(x.transpose(1, 2)).transpose(1, 2)  # Apply BN
        if self.use_sigmoid:
            x = F.sigmoid(self.fc(x[:, -1, :]))  # Apply FC to the last output and then apply sigmoid
        else:
            x = self.fc(x[:, -1, :])
        return x

# 定义模型


    
if __name__ == '__main__':
    model = GRUBNFCNet(7, 128, 64)
    X = torch.randn((50, 7, 63))
    Y = model(X)
    print(Y.shape)