import torch
import torch.nn as nn
import torch.nn.functional as F

class PositionwiseFeedForward(nn.Module):
    def __init__(self, d_model, d_ff):
        super(PositionwiseFeedForward, self).__init__()
        self.linear1 = nn.Linear(d_model, d_ff)
        self.linear2 = nn.Linear(d_ff, d_model)

    def forward(self, x):
        x = F.relu(self.linear1(x))
        x = self.linear2(x)
        return x

class EncoderLayer(nn.Module):
    def __init__(self, d_model, num_heads, d_ff):
        super(EncoderLayer, self).__init__()
        self.multi_head_attention = nn.MultiheadAttention(d_model, num_heads)
        self.feed_forward = PositionwiseFeedForward(d_model, d_ff)

    def forward(self, x, mask=None):
        # MultiheadAttention in PyTorch expects inputs of shape (L, N, E) where L is the sequence length, N is the batch size, and E is the embedding dimension.
        x = x.permute(1, 0, 2)  # Reshape x to (seq_len, B, d_model)
        x, _ = self.multi_head_attention(x, x, x, key_padding_mask=mask)
        x = x.permute(1, 0, 2)  # Reshape x back to (B, seq_len, d_model)
        x = self.feed_forward(x)
        return x

class HISTModel(nn.Module):
    def __init__(self, input_dim, d_model, num_heads, d_ff, num_layers, output_dim, seq_len):
        super(HISTModel, self).__init__()
        self.input_dim = input_dim
        self.d_model = d_model
        self.num_heads = num_heads
        self.d_ff = d_ff
        self.num_layers = num_layers
        self.output_dim = output_dim
        self.seq_len = seq_len

        self.input_projection = nn.Linear(input_dim, d_model)
        self.encoder_layers = nn.ModuleList([EncoderLayer(d_model, num_heads, d_ff) for _ in range(num_layers)])
        self.output_layer = nn.Linear(d_model * seq_len, output_dim)

    def forward(self, x):
        x = x.permute(0, 2, 1)
        x = self.input_projection(x)

        # Apply each layer in the encoder
        for layer in self.encoder_layers:
            x = layer(x)

        # Flatten and pass through the final output layer
        x = x.view(x.size(0), -1)
        x = self.output_layer(x)
        return x
    
if __name__ == "__main__":
    past_series = torch.rand(5000, 7, 63)
    model = HISTModel(7, 64, 4, 128, 2, 64, 63)
    pred_series = model(past_series)
    print(pred_series.shape)