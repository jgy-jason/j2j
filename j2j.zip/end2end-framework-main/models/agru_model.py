#%%
import torch
import torch.nn as nn
import torch.nn.functional as F

class AGRUModel(nn.Module):
    def __init__(self, input_features=7, gru_hidden_size=128, num_layers = 1,fc_out_features=64):
        super(AGRUModel, self).__init__()
        self.agru = nn.GRU(input_features, gru_hidden_size, num_layers=num_layers, batch_first=True)
        self.attn = nn.Linear(gru_hidden_size, 1)
        self.fc = nn.Linear(gru_hidden_size, fc_out_features)
        self.activation = nn.Tanh()  # 使用tanh作为非线性激活函数
        
    def forward(self, x):
        x = x.permute(0, 2, 1)
        out, _ = self.agru(x)
        attention_weights = torch.softmax(self.attn(out), dim=1)
        # attention_weights = self.activation(self.attn(out))
        context = torch.sum(attention_weights * out, dim=1)
        out = self.fc(context)
        return out

#%%
    
if __name__ == '__main__':
    model = AGRUModel(7, 128, 64)
    X = torch.ones((5000, 7, 63))
    Y = model(X)
    print(Y.shape)
# %%
