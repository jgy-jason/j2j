export CUDA_VISIBLE_DEVICES=0
data_config_name=configs/data_config_day_factor.yaml
training_config_name=configs/gru_example.yaml
log_dir=logs/day/
output_dir=ckpt_new/day/
D:/python/jupyter/研二/end2end-framework-main/python main.py --data_config $data_config_name --training_config $training_config_name --log_dir $log_dir --output_dir $output_dir