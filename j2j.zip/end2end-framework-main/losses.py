import torch
import torch.nn as nn
from utils import *

def pearson_correlation(x, y):
    """
    Compute the Pearson correlation coefficient between
    two tensors while preserving gradient information.
    """
    mean_x = torch.mean(x)
    mean_y = torch.mean(y)
    xm = x.sub(mean_x)
    ym = y.sub(mean_y)
    r_num = torch.sum(xm * ym)
    r_den = torch.sqrt(torch.sum(xm ** 2) * torch.sum(ym ** 2))
    r = r_num / r_den

    # To avoid division by zero, in case of zero variance
    r = torch.where(torch.isnan(r), torch.zeros_like(r), r)
    return r

def spearman_correlation(x, y):
    # 计算x和y的秩次，并将其转换为浮点类型
    x_rank = x.argsort().argsort().float()
    y_rank = y.argsort().argsort().float()
    
    # 计算秩次的平均值
    x_rank_mean = x_rank.mean()
    y_rank_mean = y_rank.mean()
    
    # 计算秩次的差异
    dx = x_rank - x_rank_mean
    dy = y_rank - y_rank_mean
    
    # 计算秩次差异的乘积之和，这是协方差的分子部分
    cov = (dx * dy).sum() / (len(x) - 1)
    
    # 分别计算x和y秩次的标准差
    x_std = torch.sqrt((dx ** 2).sum() / (len(x) - 1))
    y_std = torch.sqrt((dy ** 2).sum() / (len(x) - 1))
    
    # 计算并返回Spearman秩相关系数
    return cov / (x_std * y_std)


class Single_IC_Loss:
    def __init__(self):
        pass
    def __call__(self, outputs, target):
        target = target.view(1, -1)

        # Calculate correlation for each factor with the target
        # Pearson correlation coefficient is used here
        corrs = [pearson_correlation(outputs[:, i], target).unsqueeze(0) for i in range(outputs.shape[1])]
        corrs = torch.cat(corrs)
        
        # Calculate the first term of the loss function
        return torch.mean(corrs)

class Multi_IC_Loss:
    def __init__(self):
        pass
    
    def __call__(self, outputs, target):
        sum_output = torch.sum(outputs, 1)
        sum_corr = pearson_correlation(sum_output, target)
        # sum_corr = torch.sum(corrs)

        # Calculate the second term of the loss function
        return sum_corr

class Rank_IC_Loss:
    def __init__(self):
        pass
    def __call__(self, outputs, target):
        target = target.view(1, -1)

        # Calculate rank correlation for each factor with the target
        corrs = [spearman_correlation(outputs[:, i], target).unsqueeze(0) for i in range(outputs.shape[1])]
        corrs = torch.cat(corrs)
        
        # Calculate the first term of the loss function
        return torch.mean(corrs)


class MSE_Loss:
    def __init__(self):
        pass
    def __call__(self, outputs, target):
        target = target.view(1, -1)
        mse = [torch.mean(torch.pow(outputs[:, i] - target, 2)) for i in range(outputs.shape[1])]
        mse = torch.mean(torch.stack(mse))
        return mse
    
class CCCloss(nn.Module):
    def forward(self, outputs, target):
        target = target.view(1, -1)
        corrs = [pearson_correlation(outputs[:, i], target).unsqueeze(0) for i in range(outputs.shape[1])]
        corrs = torch.cat(corrs)
        
        mean1 = torch.mean(corrs)
        
        sum_output = torch.sum(outputs, 1)
        mean2 = pearson_correlation(sum_output, target)

        corr = mean1 + mean2
        
        mse_loss = MSE_Loss()
        mse = mse_loss(outputs, target)
        
        CCC = -(2 * corr / mse + 2 * corr)
        
        return CCC
        
class Corr_punishment:
    def __init__(self) -> None:
        pass
    
    def __call__(self, outputs, target):
        corrs = torch.mean(torch.corrcoef(outputs.T) ** 2)
        return corrs
    
class My_Loss(nn.Module):
    def __init__(self, config):
        super(My_Loss, self).__init__()
        self.weights = config.LossFunction.loss_weights
        self.loss_type_list = config.LossFunction.loss_list
        self.loss_list = [self.get_loss(loss_type) for loss_type in self.loss_type_list]
    def get_loss(self, loss_type):
        if loss_type in ['single_IC_loss', 'single_ic_loss']:
            return Single_IC_Loss()
        
        elif loss_type in ['multi_IC_loss', 'multi_ic_loss']:
            return Multi_IC_Loss()
        
        elif loss_type in ['rank_IC_loss', 'rank_ic_loss']:
            return Rank_IC_Loss()
        
        elif loss_type in ['ccc_loss', 'ccc']:
            return CCCloss()
        
        elif loss_type in ['mse_loss', 'mse']:
            return MSE_Loss()
        
        elif loss_type in ['corr_punishment', 'corr']:
            return Corr_punishment()
        
        else:
            raise ValueError(f'Unknown loss type: {loss_type}')
        
    def __call__(self, outputs, target):
        loss = 0
        for i in range(len(self.loss_list)):
            loss += self.weights[i] * self.loss_list[i](outputs, target)
        return loss

class CustomLoss(nn.Module):
    def __init__(self, lambda1, lambda2):
        super(CustomLoss, self).__init__()
        self.lambda1 = lambda1
        self.lambda2 = lambda2
        # self.n2 = n2

    def forward(self, outputs, target):
        
        """
        outputs 维度: T*64 T是股票个数, 64 是因子个数
        targets: 维度 T
        """
        
        # Convert target to a float tensor in case it's not
        # target = target.float()

        # Ensure that target is a 2D row vector
        target = target.view(1, -1)

        # Calculate correlation for each factor with the target
        # Pearson correlation coefficient is used here
        corrs = [pearson_correlation(outputs[:, i], target).unsqueeze(0) for i in range(outputs.shape[1])]
        corrs = torch.cat(corrs)
        
        # Calculate the first term of the loss function
        term1 = -torch.mean(corrs)

        # Calculate the sum of correlations for the second term
        # sum_outputs =
        sum_output = torch.sum(outputs, 1)
        sum_corr = pearson_correlation(sum_output, target)
        # sum_corr = torch.sum(corrs)

        # Calculate the second term of the loss function
        term2 = -self.lambda1 * sum_corr

        # Calculate the third term of the loss function
        term3 = self.lambda2 * torch.mean(torch.corrcoef(outputs.T) ** 2)
        
        # mse = [torch.mean(torch.pow(outputs[:, i] - target, 2)) for i in range(outputs.shape[1])]
        # mse = torch.mean(torch.stack(mse))
        
        # Sum all terms to get final loss
        loss_final = term1 + term2 + term3

        return loss_final





if __name__ == '__main__':
    config = load_config('configs/gru_example.yaml')
    T = 10  # Let's say we have 10 stocks
    custom_loss = My_Loss(config)
    loss2 = CustomLoss(lambda1=1.0, lambda2=0.5)
    # custom_loss = CustomLoss(lambda1=0.5, lambda2=0.5)
    outputs = torch.randn(T, 64, requires_grad=True)
    target = torch.randn(T)

    # Calculate loss
    loss = custom_loss(outputs, target)
    loss_2 = loss2(outputs, target)
    # print(f"Calculated loss: {loss}, {loss_2}")
    print(loss)
    print(loss_2)
